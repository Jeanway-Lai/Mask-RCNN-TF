import os  # 导入os库，用于处理文件和目录操作
import sys  # 导入sys库，用于访问与Python解释器相关的功能
import random  # 导入random库，用于生成随机数
import math  # 导入math库，用于数学运算，如幂、平方根等
import numpy as np  # 导入numpy库，用于处理多维数组和矩阵运算
import skimage.io  # 导入skimage.io，用于读取和保存图像文件
from PIL import Image  # 导入PIL库的Image模块，用于处理图片
import matplotlib  # 导入matplotlib库，用于创建图表
import matplotlib.pyplot as plt  # 导入pyplot模块，用于绘制图片
from nets.mrcnn import get_predict_model  # 从自定义模块nets.mrcnn导入get_predict_model函数，用于获取模型
from utils.config import Config  # 从utils.config导入Config类，用于存储和配置模型参数
from utils.anchors import get_anchors  # 导入get_anchors函数，用于获取anchor点
from utils.utils import mold_inputs, unmold_detections  # 导入图像预处理(mold_inputs)和后处理(unmold_detections)函数
from utils import visualize  # 导入visualize模块，用于结果的可视化
import keras.backend as K  # 导入Keras的后端模块，用于TensorFlow操作


'''''''''
定义了 Mask R-CNN 模型的核心类 MASK_RCNN，包括模型的初始化、加载、预测和关闭会话等功能。
'''

class MASK_RCNN(object):  # 定义一个MASK_RCNN类用于管理整个模型
    _defaults = {  # 定义模型的默认参数，包括模型路径、类别路径等
        "model_path": 'model_data/mask_rcnn_coco.h5',  # 指定预训练模型的路径
        "classes_path": 'model_data/coco_classes.txt',  # 指定存储类别名称的文件路径
        "confidence": 0.7,  # 设置模型检测的置信度阈值

        # 使用coco数据集检测的时候，IMAGE_MIN_DIM=1024，IMAGE_MAX_DIM=1024, RPN_ANCHOR_SCALES=(32, 64, 128, 256, 512)
        "RPN_ANCHOR_SCALES": (32, 64, 128, 256, 512),  # RPN层anchor的尺度
        "IMAGE_MIN_DIM": 1024,  # 图像的最小尺寸（像素）
        "IMAGE_MAX_DIM": 1024,  # 图像的最大尺寸（像素）

        # 在使用自己的数据集进行训练的时候，如果显存不足要调小图片大小
        # 同时要调小anchors
        # "IMAGE_MIN_DIM": 512,
        # "IMAGE_MAX_DIM": 512,
        # "RPN_ANCHOR_SCALES": (16, 32, 64, 128, 256)
    }

    @classmethod
    def get_defaults(cls, n):  # 一个类方法，用于获取指定默认参数值
        '''''''''
        cls: 引用类本身
        n: 参数名称
        '''
        if n in cls._defaults:  # 检查是否在默认参数字典中
            return cls._defaults[n]  # 返回对应参数值
        else:
            return "Unrecognized attribute name '" + n + "'"  # 如果没有该参数，返回错误信息

    def __init__(self, **kwargs):  # 初始化方法
        self.__dict__.update(self._defaults)  # 更新默认参数
        self.class_names = self._get_class()  # 获取所有类别名称
        self.sess = K.get_session()  # 获取当前的Keras会话
        self.config = self._get_config()  # 获取配置信息
        self.generate()  # 生成模型并载入权重

    def _get_class(self):  # 获取所有类别名称的方法
        classes_path = os.path.expanduser(self.classes_path)  # 展开用户路径
        with open(classes_path) as f:  # 打开类别文件
            class_names = f.readlines()  # 读取所有行
        class_names = [c.strip() for c in class_names]  # 去除每行的换行符
        class_names.insert(0, "BG")  # 在类别列表的索引为0的位置插入BG（背景）类别
        return class_names  # 返回类别名称列表

    def _get_config(self):  # 获取配置信息
        '''''''''
        在Python中，一个类可以通过继承另一个类来扩展其功能。继承可以让子类（在这种情况下是 InferenceConfig）获得父类（在这种情况下是 Config）的所有属性和方法。然后，子类可以添加新的属性和方法，或者覆盖（重写）父类的方法和属性。
        InferenceConfig 类通过继承 Config 类，获得了 Config 类中定义的所有属性和方法。然后，它通过在类定义中指定新的属性值或添加新的属性，来重写或扩展父类 Config 的行为：
        
        这段代码定义了一个名为 `_get_config` 的方法，它的作用是创建并返回一个配置对象，该对象包含了用于模型推理的配置参数。

        代码逻辑和作用
        - `_get_config`: 这是一个特殊的方法，以一个下划线开头，表明它是一个内部方法，仅供类内部使用。
        - `InferenceConfig`: 这是一个配置类，继承自 `Config` 基类。它重写了一些属性以适应推理过程。
        - `NUM_CLASSES`: 属性设置为类名列表的长度，这个长度包括了背景类。
        - `GPU_COUNT`: 设置为1，表示在推理时使用一个GPU。
        - `IMAGES_PER_GPU`: 设置为1，表示每个GPU处理一张图片。
        - `DETECTION_MIN_CONFIDENCE`: 设置为构造函数中传入的 `confidence` 参数，表示检测的最小置信度。
        - `NAME`: 为配置设置一个名称，这里是 "shapes"。
        - `RPN_ANCHOR_SCALES`: 从父类 `Config` 继承的属性，用于定义RPN层使用的anchors的尺度。
        - `IMAGE_MIN_DIM` 和 `IMAGE_MAX_DIM`: 分别设置处理图像的最小和最大尺寸。
        - `config.display()`: 调用 `display` 方法打印配置信息，这有助于调试和确认配置是否正确。
        - `return config`: 返回配置对象，使得可以在类的其他方法中使用这些配置。
        这个方法的主要作用是为模型推理创建一个配置对象，并且打印出所有的配置信息，以便于调试和确认。
        通过这种方式，InferenceConfig 类定制了父类 Config 的默认行为，以满足特定于推理过程的配置需求。

        在子类中，可以使用 self 来定义或重写属性，这与在父类中定义属性的方式相同。
        self 代表当前的类实例，通过 self 可以访问和设置实例的属性。在这个例子中，self.class_names、self.confidence、self.RPN_ANCHOR_SCALES、self.IMAGE_MIN_DIM 和 self.IMAGE_MAX_DIM 是从父类继承来的属性，子类通过 self 来访问和重写它们。
        '''
        class InferenceConfig(Config):  # 定义一个名为InferenceConfig的类，它继承自基类Config（继承和属性重写）
            # 可以选择不调用 super().__init__()
            # super().__init__()
            NUM_CLASSES = len(self.class_names)  # 设置类别的数量，包括背景类
            GPU_COUNT = 1  # 设置使用的GPU数量
            IMAGES_PER_GPU = 1  # 设置每个GPU处理的图片数量
            DETECTION_MIN_CONFIDENCE = self.confidence  # 设置检测的最小置信度阈值

            NAME = "shapes"  # 设置配置的名称
            RPN_ANCHOR_SCALES = self.RPN_ANCHOR_SCALES  # 设置RPN层使用的anchors的尺度
            IMAGE_MIN_DIM = self.IMAGE_MIN_DIM  # 设置处理图像的最小尺寸
            IMAGE_MAX_DIM = self.IMAGE_MAX_DIM  # 设置处理图像的最大尺寸

        config = InferenceConfig()  # 实例化InferenceConfig类，创建配置对象
        config.display()  # 调用display方法，在控制台打印配置对象的信息
        return config  # 返回配置对象，这样其他方法就可以使用这些配置参数

    def generate(self):  # 生成模型的方法
        model_path = os.path.expanduser(self.model_path)  # 展开用户路径
        assert model_path.endswith('.h5'), 'Keras model or weights must be a .h5 file.'  # 确保模型文件是.h5格式

        # 计算类别数量
        self.num_classes = len(self.class_names)

        # 载入模型，如果原来的模型里已经包括了模型结构则直接载入。
        # 否则先构建模型再载入
        self.model = get_predict_model(self.config)  # 根据配置参数创建并返回一个深度学习的模型
        self.model.load_weights(self.model_path, by_name=True)  # 加载模型权重（by_name=True 表示加载权重时会根据层的名字进行匹配。这样，如果模型架构与保存权重时的架构相同，权重将会正确加载到相应的层中。如果有些层的名称不完全匹配（例如，未使用的层），加载机制会忽略那些层）

    def detect_image(self, image):  # 检测图片的方法
        '''''''''
        image: 输入图像
        返回: 预测结果，包括区域、类别、置信度、掩膜
        '''
        image = [np.array(image)]  # 将图片转换为numpy数组，并放入列表中
        molded_images, image_metas, windows = mold_inputs(self.config, image)  # 将输入的图片进行处理

        image_shape = molded_images[0].shape  # 获取处理后的图片的形状
        anchors = get_anchors(self.config, image_shape)  # 获取anchor点
        anchors = np.broadcast_to(anchors, (1,) + anchors.shape)  # 将anchor点广播到输入尺寸

        # 使用模型预测
        detections, _, _, mrcnn_mask, _, _, _ = self.model.predict([molded_images, image_metas, anchors], verbose=0)

        # 处理预测结果，转换为最终的检测结果
        final_rois, final_class_ids, final_scores, final_masks = unmold_detections(
            detections[0], mrcnn_mask[0], image[0].shape, molded_images[0].shape, windows[0]
        )

        # 组织结果，包含区域、类别ID、置信度、掩膜
        r = {
            "rois": final_rois,  # 检测的区域
            "class_ids": final_class_ids,  # 类别ID
            "scores": final_scores,  # 置信度
            "masks": final_masks,  # 掩膜
        }

        # 可视化检测结果
        visualize.display_instances(image[0], r['rois'], r['masks'], r['class_ids'], self.class_names, r['scores'])

    def close_session(self):  # 关闭会话
        '''
        关闭TensorFlow会话
        '''
        self.sess.close()  # 关闭Keras会话