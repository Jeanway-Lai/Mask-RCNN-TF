# 纯手写、不依赖任何高级API 使用 torchvision.ops 等高阶函数 的 RoI Align 实现（基于 PyTorch 张量和基本运算），包含双线性插值采样并对每个 bin 内采样点做平均池化：
import torch, math  # 导入PyTorch
import matplotlib.pyplot as plt
import numpy as np

def bilinear_interpolate(f, x, y, H, W):
    """""""""
    对特征图 f 在浮点坐标 (x, y) 上进行双线性插值

    输入：
        f: Tensor, [C, H, W]，特征图
        x: float，采样点 x 坐标（浮点）
        y: float，采样点 y 坐标（浮点）
        H, W: 特征图的高、宽，用于边界保护

    返回：
        val: Tensor, 插值后的 [C] 特征向量
    """

    # 限制坐标在边界内：0 ≤ x < W, 0 ≤ y < H
    x = min(max(x, 0), W - 1)
    y = min(max(y, 0), H - 1)

    # 找到左上角的像素格点（向下取整）
    x0 = int(torch.floor(x).item())   # ⌊x⌋
    y0 = int(torch.floor(y).item())   # ⌊y⌋

    # 找到右下角的像素格点
    x1 = min(x0 + 1, W - 1)
    y1 = min(y0 + 1, H - 1)

    # 距离当前点到左上角格点的偏移（作为插值权重）
    wx = x - x0    # = x - ⌊x⌋
    wy = y - y0    # = y - ⌊y⌋

    # 📐 双线性插值公式：
    # v(x, y) = (1-wx)(1-wy)·v00 + wx(1-wy)·v01 + (1-wx)wy·v10 + wx·wy·v11

    # 对应变量映射：
    # v00 = f[:, y0, x0]  ← 左上角像素
    # v01 = f[:, y0, x1]  ← 右上角像素
    # v10 = f[:, y1, x0]  ← 左下角像素
    # v11 = f[:, y1, x1]  ← 右下角像素

    # 插值计算
    v00 = f[:, y0, x0]
    v01 = f[:, y0, x1]
    v10 = f[:, y1, x0]
    v11 = f[:, y1, x1]

    w00 = (1 - wx) * (1 - wy)  # 左上
    w01 = wx * (1 - wy)        # 右上
    w10 = (1 - wx) * wy        # 左下
    w11 = wx * wy              # 右下

    val = w00 * v00 + w01 * v01 + w10 * v10 + w11 * v11

    return val

def get_sample_point(x1, y1, ix, iy, sx, sy, bin_w, bin_h, sample_w, sample_h):
    """""""""
    计算 RoI Align 中一个具体采样点 (x, y) 的浮点坐标。
    最终坐标 = RoI起点 + bin起点（在RoI内） + bin内采样点的偏移
            =     y1    +   iy * bin_h        +   (sy + 0.5) * bin_h / sample_h
             
    就像：一栋大楼的总楼层高度 = 楼栋起始楼层 + 当前单元起点 + 单元内的具体位置。
    参数解释：
    - (x1, y1): 当前 RoI 的左上角坐标（float）
    - (ix, iy): 当前 bin 的行列索引（第几行、第几列）
    - (sx, sy): 当前 bin 内的第几个采样点（采样点索引）
    - bin_w, bin_h: 每个 bin 的宽高（RoI 的宽高 / pooled size）
    - sample_w, sample_h: 每个 bin 内水平方向、垂直方向采样点数量
    """
    # -------------------------------------
    roi_start_w = x1  # RoI 左上角浮点坐标
    roi_start_h = y1

    # 🎯 1. bin 内部的左上角偏移量（相对于 RoI 起点）
    # 当前 bin 的行/列索引（0~pooled_h-1） * 每个 bin 的高 / 宽 = 索引每个bin的每个像素，当前 bin 的索引乘以每个 bin 的尺寸，就可以理解为“当前 bin 在整个 RoI 中的位置偏移量。
    # 假设 bin 是 7x7 网格中的第 (iy, ix) 个
    bin_x_offset = ix * bin_w  # 第 ix 列 → 在 x 方向上偏移了 ix 个 bin 宽度（当前 bin 的起始 x 坐标（表示这个 bin 相对整个 RoI 的横向起始位置）） eg. 第2列 bin，相对 x1 向右偏移2个bin_w
    bin_y_offset = iy * bin_h  # 第 iy 行 → 在 y 方向上偏移了 iy 个 bin 高度（当前 bin 的起始 y 坐标（表示这个 bin 相对整个 RoI 的纵向起始位置）） eg. 第3行 bin，相对 y1 向下偏移3个bin_h

    # -------------------------------------
    # 🎯 2. bin 内部的采样点相对偏移（相对 bin 左上角）
    # bin 内第 sy、sx 个采样点在当前 bin 中的偏移量（小数）
    # (sx + 0.5) 表示在 bin 中的中心采样位置，例如中间的点
    # sample_y_offset：bin 内部，当前 sy 号采样点在 y 上的偏移
    # sample_x_offset：bin 内部，当前 sx 号采样点在 x 上的偏移
    sample_x_offset = (sx + 0.5) * bin_w / sample_w
    sample_y_offset = (sy + 0.5) * bin_h / sample_h  # 采样点在 bin 内纵向偏移（单位：像素） eg. sy=1，表示第2个点

    # -------------------------------------
    # 🎯 3. 当前采样点相对整个 RoI 的坐标偏移（加上左上角起点）（RoI 内部相对位置）
    relative_x = bin_x_offset + sample_x_offset
    relative_y = bin_y_offset + sample_y_offset

    # -------------------------------------
    # 🎯 4. 最终采样点相对整张特征图（feature map）的位置（float）
    # 即将相对 RoI 的位置，加上 RoI 起点，得到特征图上的坐标
    x = roi_start_w + relative_x
    y = roi_start_h + relative_y

    return x, y

def roi_extract_pure(features, rois, output_size, spatial_scale=1.0, sampling_ratio=2, mode='align', pooling='avg'):
    """""""""
    通用的 RoI 特征提取器，支持 RoI Align 与 RoI Pooling。

    参数说明：
        features: Tensor, 输入特征图，形状为 [N, C, H, W]
        rois: Tensor, 感兴趣区域（Regions of Interest），形状为 [K, 5]，每行为 [batch_idx, x1, y1, x2, y2]
        output_size: tuple, 每个 RoI 输出的固定尺寸 (out_h, out_w)
        spatial_scale: float, 将 RoI 坐标从原图映射到特征图的比例因子（例如 1/16）
        sampling_ratio: int, 每个 bin 内的采样点数量（仅 RoI Align 用）
        mode: str, 'align' 或 'pooling'，控制使用哪种操作
        pooling: str, 'avg' 或 'max'，仅 RoI Align 时生效
    返回：
        output: Tensor, 形状为 [K, C, out_h, out_w]，每个 RoI 对应的输出特征
    """
    # 获取输入特征图的形状
    N, C, H, W = features.shape
    K = rois.size(0)  # RoI 数量
    out_h, out_w = output_size  # 输出特征图尺寸

    # 初始化输出张量
    output = torch.zeros((K, C, out_h, out_w), dtype=features.dtype, device=features.device)

    # 遍历每个 RoI
    for idx in range(K):
        batch_idx = int(rois[idx, 0].item())  # 获取 RoI 所属 batch 索引

        # --------------------- 🚩【调用双线性插值的开始位置】---------------------
        if mode == 'align':  # 进入 RoI Align 分支
            # RoI Align 使用浮点坐标 + 双线性插值
            x1 = rois[idx, 1] * spatial_scale
            y1 = rois[idx, 2] * spatial_scale
            x2 = rois[idx, 3] * spatial_scale
            y2 = rois[idx, 4] * spatial_scale

            roi_w = max(x2 - x1, 1.0)  # RoI 宽度最小为1
            roi_h = max(y2 - y1, 1.0)  # RoI 高度最小为1

            bin_w = roi_w / out_w  # 每个 bin 的宽度
            bin_h = roi_h / out_h  # 每个 bin 的高度

            # 计算采样点数（固定或自适应）
            if sampling_ratio > 0:
                sample_w = sample_h = sampling_ratio
            else:
                sample_w = int(torch.ceil(roi_w / out_w).item())
                sample_h = int(torch.ceil(roi_h / out_h).item())

            # 遍历输出特征图每个位置
            for iy in range(out_h):
                for ix in range(out_w):
                    vals = []  # 当前 bin 内的采样值
                    
                    # 遍历 bin 内采样点
                    for sy in range(sample_h):
                        for sx in range(sample_w):
                            # 均匀划分好Roi的网格中，在网格中找到每个网格（bin）里要采样的那个点在整个特征图上的精确位置（浮点坐标），好让后面用插值准确取值。
                            # 算出每个 bin 内采样点相对于整张特征图的精确浮点坐标，以便后续用双线性插值得到该点的特征值。
                            # 计算当前采样点在特征图中的精确坐标位置（浮点数）
                            y = y1 + iy * bin_h + (sy + 0.5) * bin_h / sample_h
                            x = x1 + ix * bin_w + (sx + 0.5) * bin_w / sample_w
                            x, y = get_sample_point(x1, y1, ix, iy, sx, sy, bin_w, bin_h, sample_w, sample_h)

                            # ✅ ✅ ✅ 🚀【这里调用双线性插值函数】🚀 ✅ ✅ ✅
                            val = bilinear_interpolate(features[batch_idx], x, y, H, W)
                            vals.append(val)

                            # 限制采样点保证不越界
                            y = min(max(y, 0), H - 1)
                            x = min(max(x, 0), W - 1)

                            # 获取周围整数像素坐标（整数网格索引（用于插值））
                            y0 = int(torch.floor(y).item())  # 上邻像素 y
                            x0 = int(torch.floor(x).item())  # 左邻像素 x
                            y1p = min(y0 + 1, H - 1)  # 下邻像素 y
                            x1p = min(x0 + 1, W - 1)  # 右邻像素 x

                            # 插值权重（距离决定权重）
                            wy = y - y0  # 当前点 y 距离上边界
                            wx = x - x0  # 当前点 x 距离左边界

                            # 双线性插值权重计算：
                            # 插值公式：
                            # v = (1-wx)(1-wy) * v00 + wx*(1-wy) * v01 + (1-wx)*wy * v10 + wx*wy * v11
                            #
                            # 对应变量含义：
                            # v00 = f[:, y0, x0]  ← 左上角像素值
                            # v01 = f[:, y0, x1p] ← 右上角像素值
                            # v10 = f[:, y1p, x0] ← 左下角像素值
                            # v11 = f[:, y1p, x1p]← 右下角像素值
                            # wx, wy 分别是当前点到左边和上边的距离（介于 0~1 之间）
                            #
                            # 权重：
                            w00 = (1 - wy) * (1 - wx)  # 左上角
                            w01 = (1 - wy) * wx  # 右上角
                            w10 = wy * (1 - wx)  # 左下角
                            w11 = wy * wx  # 右下角

                            # 提取当前 RoI 样本所属 batch 的特征图
                            f = features[batch_idx]

                            # 根据权重插值（插值值 = 4个像素点 × 对应权重求和）
                            val = (
                                    w00 * f[:, y0, x0] +
                                    w01 * f[:, y0, x1p] +
                                    w10 * f[:, y1p, x0] +
                                    w11 * f[:, y1p, x1p]
                            )
                            vals.append(val)  # 保存当前采样点结果

                    if vals:
                        samples = torch.stack(vals, dim=0)  # 将所有采样点堆叠

                        # 把一个bin里面的池化：平均或最大的结果存放到output
                        if pooling == 'max':
                            output[idx, :, iy, ix] = samples.max(dim=0).values
                        else:
                            output[idx, :, iy, ix] = samples.mean(dim=0)

        elif mode == 'pooling':
            # RoI Pooling 使用整数坐标 + 最大池化
            x1 = int(torch.floor(rois[idx, 1] * spatial_scale).item())
            y1 = int(torch.floor(rois[idx, 2] * spatial_scale).item())
            x2 = int(torch.ceil(rois[idx, 3] * spatial_scale).item())
            y2 = int(torch.ceil(rois[idx, 4] * spatial_scale).item())

            roi_w = max(x2 - x1, 1)  # 保证至少 1 像素
            roi_h = max(y2 - y1, 1)

            bin_w = roi_w // out_w  # 整除划分 bin
            bin_h = roi_h // out_h

            # 遍历输出特征图每个 bin
            for iy in range(out_h):
                for ix in range(out_w):
                    # 计算当前 bin 在特征图中的起止位置（整数坐标）
                    start_y = y1 + iy * bin_h
                    end_y = y1 + (iy + 1) * bin_h
                    start_x = x1 + ix * bin_w
                    end_x = x1 + (ix + 1) * bin_w

                    # 防止越界
                    start_y = min(max(start_y, 0), H)
                    end_y = min(max(end_y, 0), H)
                    start_x = min(max(start_x, 0), W)
                    end_x = min(max(end_x, 0), W)

                    # 空 bin（无像素）
                    if end_y <= start_y or end_x <= start_x:
                        output[idx, :, iy, ix] = 0
                    else:
                        # 提取当前 bin 区域特征
                        region = features[batch_idx, :, start_y:end_y, start_x:end_x]

                        # 在每个通道上做最大池化
                        output[idx, :, iy, ix] = region.reshape(C, -1).max(dim=1).values

        else:
            # 模式非法时抛出错误
            raise ValueError(f"Unsupported mode: {mode}. Use 'align' or 'pooling'.")

    # 返回所有 RoI 的对齐特征
    return output

def roi_align_pure(features, rois, output_size, spatial_scale=1.0, sampling_ratio=2, pooling='avg'):
    """""""""
    纯手写实现 RoI Align（平均池化版本，包含双线性插值）
    Args:
        features: 输入特征图，形状为[N, C, H, W]
        rois: 感兴趣区域，[K, 5]，格式为[batch_idx, x1, y1, x2, y2]
        output_size: 输出特征图大小，如(7, 7)
        spatial_scale: 将RoI从原图尺度映射到特征图尺度的缩放因子（RoI 的输入坐标是原图坐标，先乘上 spatial_scale 变换到 特征图尺度）
        sampling_ratio: 每个bin中每个方向上的采样点数（如果<=0则自动计算）
    Returns:
        output: 输出特征图，[K, C, output_h, output_w]
    """
    N, C, H, W = features.shape  # 获取输入特征图的维度信息
    K = rois.size(0)  # RoI的数量
    out_h, out_w = output_size  # 获取输出特征图的高和宽
    output = torch.zeros((K, C, out_h, out_w), dtype=features.dtype, device=features.device)  # 初始化输出张量

    for idx in range(K):  # 遍历每个 RoI
        batch_idx = int(rois[idx, 0].item())  # 获取当前RoI所属batch图像的索引

        # 将RoI从原图空间（根据idx索引获取每一个Roi的四个坐标）映射到特征图空间
        x1 = rois[idx, 1] * spatial_scale
        y1 = rois[idx, 2] * spatial_scale
        x2 = rois[idx, 3] * spatial_scale
        y2 = rois[idx, 4] * spatial_scale

        roi_w = max(x2 - x1, 1.0)  # 计算RoI宽度，最小为1
        roi_h = max(y2 - y1, 1.0)  # 计算RoI高度，最小为1

        # 划分好 Roi 每个网格的宽度和高度，算出Bin，原来 Faster RCNN 做 ROI Pooling 划分的网格，然后对每个网格做 Max Pooling 的那个网格，这里先算出每个网格的大小，只是 Roi Align 不和 Roi Pooling一样量化
        # Bin 是一个关键概念，指的是将 感兴趣区域（RoI） 划分成的若干等分的子窗口（Sub-region）。它的作用是帮助将不同大小的 RoI 转换为固定大小的输出特征图。
        '''
        ### **1. Bin 的定义**
        - **Bin** 是英文 "Binary Digit"（二进制位） 或 "Container"（容器） 的缩写，在 RoI 操作中特指 **划分的网格单元**。
        - Bin 来自统计学中的 "Binning"（分箱），指将连续数据划分为离散区间。像把数据放入不同的“箱子”（Bins）中，RoI 操作也是将区域划分为子窗口（Bins）进行处理。类似图像处理中的 "像素分块" 或 "网格划分"。
        - 实际含义："子窗口" 或 "网格单元"（最贴切）。在 RoI 上下文中，常直接称为 "Bin"（不翻译）或 "区域分块"。
        - 例如：如果要将一个 RoI 转换为 `2×2` 的输出，就需要将 RoI **均匀划分** 为 `2×2=4` 个 Bins（即 4 个子区域），然后在每个 Bin 内进行特征采样或池化。
        
        ---
        
        ### **2. Bin 的作用**
        - **解决尺寸不一致问题**：RoI 的尺寸可能各不相同（如有的 RoI 是 `100×100`，有的是 `50×50`），但后续全连接层需要固定大小的输入（如 `7×7`）。
        - **通过 Bins 标准化**：
        - 将 RoI 划分为 `k×k` 个 Bins（如 `7×7`）。
        - 对每个 Bin 内的特征进行池化或插值，生成固定大小的输出。
        
        ---
        
        ### **3. Bin 在 RoI Align 和 RoI Pooling 中的区别**
        | **操作**| **Bin 的处理方式**| **是否量化坐标** |
        |----------------|-----------------------------------------------------------------------------------|------------------|
        | **RoI Pooling** | 将 RoI 的边界坐标取整到特征图网格点，再划分 Bins，最后对每个 Bin 做最大池化。| 是（引入误差）|
        | **RoI Align**| 直接按浮点坐标划分 Bins，在 Bin 内通过双线性插值采样特征值，避免量化误差。| 否（更精确）|
        
        ---
        
        ### **4. 具体示例**
        假设有一个 RoI 的坐标为 `(x1, y1, x2, y2) = (1.4, 1.4, 5.7, 5.7)`，需要输出 `2×2` 的特征图：
        1. **划分 Bins**：
        - 水平方向：宽度 = `5.7 - 1.4 = 4.3` → 每个 Bin 宽度 = `4.3 / 2 = 2.15`
        - 垂直方向：高度 = `5.7 - 1.4 = 4.3` → 每个 Bin 高度 = `4.3 / 2 = 2.15`
        - 因此，4 个 Bins 的边界坐标为：
        - Bin 1: `(1.4, 1.4)` 到 `(3.55, 3.55)`
        - Bin 2: `(3.55, 1.4)` 到 `(5.7, 3.55)`
        - Bin 3: `(1.4, 3.55)` 到 `(3.55, 5.7)`
        - Bin 4: `(3.55, 3.55)` 到 `(5.7, 5.7)`
        
        2. **RoI Align 的 Bin 内操作**：
        - 在每个 Bin 的中心点（或其他采样点）通过双线性插值计算特征值。
        - 例如，Bin 1 的中心点是 `(2.475, 2.475)`，根据周围4个特征图网格点插值得到该点值。
        
        3. **RoI Pooling 的 Bin 内操作**：
        - 先将 RoI 坐标取整到 `(1, 1, 6, 6)`，再划分 Bins：
        - Bin 1: `(1, 1)` 到 `(3, 3)`
        - Bin 2: `(4, 1)` 到 `(6, 3)`
        - ...
        - 直接对 Bin 内所有特征值取最大值（丢失浮点位置信息）。
        
        ---
        
        ### **5. 为什么 Bin 设计重要？**
        - **RoI Pooling 的缺陷**：因量化（取整）导致 Bin 边界与真实 RoI 不对齐，影响小目标检测精度。
        - **RoI Align 的改进**：通过浮点划分 Bins + 插值，保留亚像素级精度，适合实例分割（如 Mask R-CNN）。
        
        ---
        
        ### **总结**
        - **Bin** 是 RoI 划分的子窗口，用于将任意大小的 RoI 转换为固定尺寸输出。
        - **RoI Align** 通过浮点 Bins + 插值避免量化误差，而 **RoI Pooling** 因量化 Bins 会丢失位置细节。
        - 理解 Bin 是掌握 RoI 操作的核心，尤其在处理高精度任务（如分割）时至关重要。
        
        在计算机视觉（尤其是 RoI 操作）中，**Bin** 的中文理解需结合其实际功能，而非直译英文缩写。以下是具体解释：

        ### **1. 中文术语**
        - **直译**：
        - **"Binary Digit"**（二进制位）→ 与 Bin 在 RoI 中的含义无关。
        - **"Container"**（容器）→ 部分相关，但不够准确。
        - **实际含义**：
        - **"子窗口"** 或 **"网格单元"**（最贴切）。
        - 在 RoI 上下文中，常直接称为 **"Bin"**（不翻译）或 **"区域分块"**。
        
        ---
        
        ### **2. 为什么叫 Bin？**
        - **词源**：来自统计学中的 **"Binning"**（分箱），指将连续数据划分为离散区间。
        - **类比**：
        - 像把数据放入不同的“箱子”（Bins）中，RoI 操作也是将区域划分为子窗口（Bins）进行处理。
        - 类似图像处理中的 **"像素分块"** 或 **"网格划分"**。
        
        ---
        
        ### **3. 中文场景下的理解**
        在 RoI Align/Pooling 中，Bin 的核心作用是：
        1. **划分区域**：将 RoI 切割为固定数量的子区域（如 2×2、7×7 的 Bins）。
        2. **特征聚合**：在每个 Bin 内池化或插值，生成固定大小的输出。
        
        **推荐术语**：
        - **学术论文/代码**：保留英文 **"Bin"**（如“每个 Bin 内采样4个点”）。
        - **中文解释**：使用 **"子窗口"** 或 **"分块单元"**（例如：“将 RoI 划分为 4 个子窗口”）。
        
        ---
        
        ### **4. 示例对比**
        | **英文描述**| **中文对应表述**|
        |-------------------------------|--------------------------------------|
        | "Divide the RoI into 2×2 Bins" | "将 RoI 划分为 2×2 个子窗口"|
        | "Max pooling within each Bin"| "在每个分块单元内做最大池化"|
        
        ---
        
        ### **5. 总结**
        - **Bin 的中文本质**：**子窗口**或**分块单元**（强调“划分”和“局部处理”）。
        - **使用建议**：技术讨论中可直接用 **Bin**，中文解释时替换为 **子窗口**。
        
        这种划分思想在计算机视觉中非常常见（如 HOG 特征中的细胞单元、注意力机制中的分块），理解 Bin 有助于掌握更多类似操作。
        '''
        bin_w = roi_w / out_w  # 每个bin的宽度
        bin_h = roi_h / out_h  # 每个bin的高度

        if sampling_ratio > 0:
            sample_w = sample_h = sampling_ratio  # 使用固定数量的采样点（横向和纵向均为 sampling_ratio，每个 bin 里面要采样多少个像素点（精度）
        else:
            sample_w = int(torch.ceil(roi_w / out_w).item())  # 自适应计算采样点数
            sample_h = int(torch.ceil(roi_h / out_h).item())
        # 遍历 ROI 中每一个网格
        for iy in range(out_h):  # 遍历输出特征图的高度方向
            for ix in range(out_w):  # 遍历输出特征图的宽度方向
                vals = []  # 保存当前bin内所有采样点的值
                for sy in range(sample_h):  # 高方向采样
                    for sx in range(sample_w):  # 宽方向采样
                        # 定位后续双线性插值使用插值点，这里正是为了在每个 bin（子窗口）里“均匀撒点”做双线性插值做铺垫——它告诉你每个采样点在特征图上的 浮点坐标，插值时再去读周围 4 个整数像素并加权。
                        # 计算采样点在特征图上的Y坐标（浮点数）
                        y = y1 + iy * bin_h + (sy + 0.5) * bin_h / sample_h
                        # 计算采样点在特征图上的X坐标（浮点数）
                        x = x1 + ix * bin_w + (sx + 0.5) * bin_w / sample_w

                        # Clamp，确保坐标不会越界
                        y = min(max(y, 0), H - 1)
                        x = min(max(x, 0), W - 1)

                        y0 = int(torch.floor(y).item())  # 获取采样点上方像素Y索引
                        x0 = int(torch.floor(x).item())  # 获取采样点左侧像素X索引
                        y1p = min(y0 + 1, H - 1)  # 下方像素的Y索引，防止越界
                        x1p = min(x0 + 1, W - 1)  # 右侧像素的X索引，防止越界

                        wy = y - y0  # 采样点Y方向的插值权重
                        wx = x - x0  # 采样点X方向的插值权重

                        # 计算四个邻近像素点的双线性插值权重
                        w00 = (1 - wy) * (1 - wx)  # 左上角
                        w01 = (1 - wy) * wx        # 右上角
                        w10 = wy * (1 - wx)        # 左下角
                        w11 = wy * wx              # 右下角

                        f = features[batch_idx]  # 当前RoI对应batch的特征图

                        # 对四个邻近点按权重进行加权求和，得到插值结果
                        val = (
                            w00 * f[:, y0, x0]
                            + w01 * f[:, y0, x1p]
                            + w10 * f[:, y1p, x0]
                            + w11 * f[:, y1p, x1p]
                        )
                        vals.append(val)  # 保存当前采样点插值结果

                if vals:  # 如果有采样点（正常情况）
                    samples = torch.stack(vals, dim=0)  # 将当前 bin 中所有采样点的特征值堆叠成张量，stack 操作只是组合数据，不是池化
                    # 池化操作：平均或最大
                    if pooling == 'max':
                        output[idx, :, iy, ix] = samples.max(dim=0).values  # 最大池化
                    else:
                        output[idx, :, iy, ix] = samples.mean(dim=0)  # 平均池化，对堆叠后的采样点沿第0维求平均，这一步才是执行平均池化，将多个采样结果聚合为单个输出值

    return output  # 返回所有RoI的对齐特征结果（RoI Align 的输出仍然处于特征图尺度）

def roi_pooling_pure(features, rois, output_size, spatial_scale=1.0):
    """
    手写实现 RoI Pooling（每个 bin 内做最大池化，使用整数边界，无插值）
    Args:
        features: 输入特征图 [N, C, H, W]
        rois: 感兴趣区域 [K, 5]，格式为 [batch_idx, x1, y1, x2, y2]
        output_size: 输出大小，如 (7, 7)
        spatial_scale: 将 RoI 从原图坐标映射到特征图坐标的缩放因子
    Returns:
        output: 对齐后的特征 [K, C, out_h, out_w]
    """
    N, C, H, W = features.shape  # 获取输入特征图的形状
    K = rois.size(0)             # 获取 RoI 的数量
    out_h, out_w = output_size   # 输出特征图大小（每个 RoI 输出尺寸）

    # 初始化输出张量，大小为 [K, C, out_h, out_w]
    output = torch.zeros((K, C, out_h, out_w), dtype=features.dtype, device=features.device)

    # 遍历每一个 RoI
    for idx in range(K):
        # 获取当前 RoI 所属图像在 batch 中的索引（第0维）
        batch_idx = int(rois[idx, 0].item())

        # RoI坐标从原图映射到特征图坐标，并【向下取整】和【向上取整】
        # ✅【修改点 1：从浮点坐标改为离散整数坐标】（即量化）
        # 获取 RoI 坐标，并将其映射到特征图尺度（乘上 spatial_scale）
        # ✅ RoI Pooling 采用的是【整数边界】，因此对坐标做 floor 和 ceil（向下/向上取整）
        x1 = int(torch.floor(rois[idx, 1] * spatial_scale).item())  # 左上角 x
        y1 = int(torch.floor(rois[idx, 2] * spatial_scale).item())  # 左上角 y
        x2 = int(torch.ceil(rois[idx, 3] * spatial_scale).item())   # 右下角 x
        y2 = int(torch.ceil(rois[idx, 4] * spatial_scale).item())   # 右下角 y

        # 计算当前 RoI 的宽度和高度（至少为1）
        roi_w = max(x2 - x1, 1)
        roi_h = max(y2 - y1, 1)

        # 将 RoI 划分为 out_h × out_w 个 bin，计算每个 bin 的大小（整除）
        bin_w = roi_w // out_w  # 每个 bin 的宽度
        bin_h = roi_h // out_h  # 每个 bin 的高度

        # 遍历输出特征图的每一个位置（每个位置对应一个 bin）
        for iy in range(out_h):  # 高方向的 bin 索引
            for ix in range(out_w):  # 宽方向的 bin 索引
                # ✅【修改点 2：不做浮点采样，直接对整数bin区域池化】
                # 计算当前 bin 的起始和结束坐标（整数坐标）
                start_y = y1 + iy * bin_h  # 当前 bin 起始 y 坐标
                end_y = y1 + (iy + 1) * bin_h  # 当前 bin 结束 y 坐标
                start_x = x1 + ix * bin_w  # 当前 bin 起始 x 坐标
                end_x = x1 + (ix + 1) * bin_w  # 当前 bin 结束 x 坐标

                # 对起始和结束坐标进行边界裁剪，防止越界
                start_y = min(max(start_y, 0), H)
                end_y = min(max(end_y, 0), H)
                start_x = min(max(start_x, 0), W)
                end_x = min(max(end_x, 0), W)

                # 如果该 bin 无有效区域（可能出现 degenerate case），则赋值为0
                if end_y <= start_y or end_x <= start_x:
                    output[idx, :, iy, ix] = 0  # 空 bin，赋0
                else:
                    # ✅【此处为 RoI Pooling 的核心：直接对 bin 区域做最大池化】
                    # 提取当前 bin 区域的特征值，形状为 [C, bin_h, bin_w]
                    region = features[batch_idx, :, start_y:end_y, start_x:end_x]

                    # 将 bin 区域展开为二维（C, H×W），然后在每个通道上取最大值
                    output[idx, :, iy, ix] = region.reshape(C, -1).max(dim=1).values

    # 返回所有 RoI 的最大池化结果
    return output

def upscale_and_overlay_on_feature(feature_map, roi, roi_output, method='align', upscale=4):
    """
    将 RoI 输出反向映射（上采样）回原特征图区域，并叠加展示在特征图上
    Args:
        feature_map: [H, W] 原始特征图的某一通道
        roi: [x1, y1, x2, y2]
        roi_output: [h, w] RoI 输出（某通道）
        method: 'align' or 'pool'
        upscale: 上采样倍数（便于更清晰对比）
    """
    x1, y1, x2, y2 = roi
    h, w = roi_output.shape

    # 将 roi_output 上采样到原图坐标尺寸（roi大小）
    roi_h = max(int(y2 - y1), 1)
    roi_w = max(int(x2 - x1), 1)

    # 使用双线性插值将输出缩放回 RoI 区域大小
    roi_output_up = torch.nn.functional.interpolate(
        roi_output.unsqueeze(0).unsqueeze(0), size=(roi_h, roi_w), mode='bilinear', align_corners=False
    ).squeeze().detach().cpu().numpy()

    # 复制特征图，叠加显示热力图
    img = feature_map.cpu().numpy().copy()

    fig, ax = plt.subplots(figsize=(6, 6))
    ax.imshow(img, cmap='gray')
    ax.imshow(roi_output_up, cmap='jet', alpha=0.5, extent=(x1, x2, y2, y1))  # 注意y轴方向反转
    ax.set_title(f'Overlay {method.upper()} Output on Feature Map')
    ax.axis('off')
    plt.show()

def visualize_precision_difference(features, rois, out_pool, out_align):
    """
    展示 RoI Align 与 RoI Pooling 对同一区域的“热力响应图”差异
    """
    for idx in range(rois.shape[0]):
        fmap = features[0, 0]  # 只可视化第0通道
        roi = rois[idx, 1:].tolist()

        print(f"\n🔍 RoI {idx}: {roi}")
        print("➡️ 显示 RoI Pooling 的输出热力图覆盖原图")
        upscale_and_overlay_on_feature(fmap, roi, out_pool[idx, 0], method='pool')

        print("➡️ 显示 RoI Align 的输出热力图覆盖原图")
        upscale_and_overlay_on_feature(fmap, roi, out_align[idx, 0], method='align')

        print("🟰 对比结果：你应该看到 Align 更平滑、边界对得更准，Pool 更块状和偏移。")

def visualize_roi_results(features, rois, out_pool, out_align, output_size=(7, 7)):
    """
    可视化 RoI Pooling 与 RoI Align 的结果对比。
    Args:
        features: 原始特征图 [N, C, H, W]
        rois: 输入的 RoIs [K, 5]
        out_pool: roi_pooling_pure 的输出 [K, C, out_h, out_w]
        out_align: roi_align_pure 的输出 [K, C, out_h, out_w]
    """
    N, C, H, W = features.shape
    K = rois.shape[0]

    for idx in range(K):
        fig, axs = plt.subplots(1, 4, figsize=(20, 5))

        # 原始特征图的第0通道
        img = features[0, 0].cpu().numpy()
        axs[0].imshow(img, cmap='viridis')
        axs[0].set_title(f'Feature Map (Channel 0)\nRoI {idx}')

        # 绘制 RoI 边框（坐标未缩放，假设 spatial_scale=1.0）
        x1, y1, x2, y2 = rois[idx, 1:].tolist()
        rect = plt.Rectangle((x1, y1), x2 - x1, y2 - y1,
                             edgecolor='red', facecolor='none', linewidth=2)
        axs[0].add_patch(rect)
        axs[0].axis('off')

        # 显示 RoI Pooling 输出结果
        axs[1].imshow(out_pool[idx, 0].cpu().numpy(), cmap='viridis')
        axs[1].set_title(f'RoI Pooling Output\n(7x7, Channel 0)')
        axs[1].axis('off')

        # 显示 RoI Align 输出结果
        axs[2].imshow(out_align[idx, 0].cpu().numpy(), cmap='viridis')
        axs[2].set_title(f'RoI Align Output\n(7x7, Channel 0)')
        axs[2].axis('off')

        # 差异图（Align - Pooling）
        diff = out_align[idx, 0] - out_pool[idx, 0]
        axs[3].imshow(diff.cpu().numpy(), cmap='bwr', vmin=-diff.abs().max(), vmax=diff.abs().max())
        axs[3].set_title(f'Difference (Align - Pooling)')
        axs[3].axis('off')

        plt.tight_layout()
        plt.show()

# 测试
if __name__ == "__main__":
    '''
    **说明：**
    
    1. **Spatial Scale**：先将原图坐标映射到特征图上。
    2. **Bin 划分**：将 RoI 区域等分为 `out_h × out_w` 个小格。
    3. **采样**：每个小格内采样 `sampling_ratio × sampling_ratio` 个点，并对它们做双线性插值（手动计算插值权重）。
    4. **平均池化**：对一个小格内的所有采样点取均值，得到该 bin 的输出特征。
    
    这样就实现了最基础的 RoI Align 算子，完全无依赖高阶库。
    '''
    feats = torch.randn(1, 3, 64, 64)  # 构造输入特征图 [N=1, C=3, H=64, W=64]
    rois = torch.tensor([
        [0, 5.0, 5.0, 25.0, 25.0],  # 第一个RoI，batch索引为0
        [0, 30.0, 30.0, 60.0, 60.0]  # 第二个RoI，batch索引为0
    ])  # 定义两个 RoI

    # 选择 RoI Align + 平均池化
    roi_extract_pure(feats, rois, (7, 7), spatial_scale=1.0, sampling_ratio=2, mode='align', pooling='avg')

    # 选择 RoI Align + 最大池化
    roi_extract_pure(feats, rois, (7, 7), mode='align', pooling='max')

    # 选择 RoI Pooling（固定最大池化）
    roi_extract_pure(feats, rois, (7, 7), mode='pooling')

    out_pool = roi_pooling_pure(feats, rois, output_size=(7, 7), spatial_scale=1.0)
    print(out_pool)  # 打印输出的形状，预期为 [2, 3, 7, 7]
    print(out_pool.shape)  # 打印输出的形状，预期为 [2, 3, 7, 7]

    out_align = roi_align_pure(feats, rois, output_size=(7, 7), spatial_scale=1.0, sampling_ratio=2)
    print(out_align)  # 打印输出的形状，预期为 [2, 3, 7, 7]
    print(out_align.shape)  # 打印输出的形状，预期为 [2, 3, 7, 7]

    visualize_precision_difference(feats, rois, out_pool, out_align)

    visualize_roi_results(feats, rois, out_pool=roi_pooling_pure(feats, rois, (7, 7)),
                          out_align=roi_align_pure(feats, rois, (7, 7), sampling_ratio=2))

    raise

# ---------------------------------------------------------------------------------------------------------------------
# 为了让手写的 RoI Align 支持 **反向传播（可导）**，我们不需要显式写出反向函数，只需确保所使用的所有操作都是 **PyTorch 的自动求导机制支持的张量操作**，并且避免使用 `.item()`（它会打断计算图）。
#
# 下面是一个完整的、**支持反向传播的版本**，保留你之前的逻辑（双线性插值 + 平均池化），并进行了如下修改：
#
# ---
#
# ### ✅ 修改要点：
#
# * 不再使用 `.item()` 转换为 Python 标量。
# * 所有权重、坐标计算和平均池化都使用张量操作。
# * 保证所有变量在 autograd 路径中可追踪。
#
# ---
#
# ### ✅ 可导版 `roi_align_autograd`：
import torch  # 导入 PyTorch 库，用于张量运算

def roi_align_autograd(features, rois, output_size, spatial_scale=1.0, sampling_ratio=2):
    """
    可导版本的 RoI Align 实现（支持反向传播），使用双线性插值与平均池化
    Args:
        features: 输入特征图，形状为 [N, C, H, W]
        rois: 感兴趣区域 [K, 5]，每行为 (batch_index, x1, y1, x2, y2)
        output_size: 输出特征图大小 (out_h, out_w)
        spatial_scale: 从原图到特征图的缩放比例
        sampling_ratio: 每个 bin 的采样点数（若 <= 0，则自适应计算）
    Returns:
        Tensor: 形状为 [K, C, out_h, out_w] 的对齐特征
    """
    N, C, H, W = features.shape  # 提取输入特征图的维度信息
    K = rois.size(0)  # RoI 的数量
    out_h, out_w = output_size  # 输出特征图的高和宽

    # 初始化输出张量，全部填充为0
    output = torch.zeros((K, C, out_h, out_w), dtype=features.dtype, device=features.device)

    for i in range(K):  # 遍历每一个 RoI
        roi = rois[i]  # 当前 RoI
        batch_idx = int(roi[0])  # RoI 所属的图像索引，转换为 int（非计算图变量）

        # 将 RoI 坐标缩放到特征图尺度
        x1 = roi[1] * spatial_scale
        y1 = roi[2] * spatial_scale
        x2 = roi[3] * spatial_scale
        y2 = roi[4] * spatial_scale

        # 计算 RoI 的宽和高，最小为 1
        roi_w = torch.clamp(x2 - x1, min=1.0)
        roi_h = torch.clamp(y2 - y1, min=1.0)

        # 计算每个 bin 的宽和高
        bin_w = roi_w / out_w
        bin_h = roi_h / out_h

        # 如果用户指定了采样率，则使用固定数量，否则根据 RoI 大小自适应计算
        if sampling_ratio > 0:
            sample_w = sample_h = sampling_ratio
        else:
            sample_w = int(torch.ceil(roi_w / out_w))
            sample_h = int(torch.ceil(roi_h / out_h))

        for iy in range(out_h):  # 遍历输出特征图的高度方向
            for ix in range(out_w):  # 遍历输出特征图的宽度方向
                samples = []  # 用于存储当前 bin 中所有采样点的插值结果

                for sy in range(sample_h):  # 遍历 bin 内高方向的采样点
                    for sx in range(sample_w):  # 遍历 bin 内宽方向的采样点
                        # 计算当前采样点在特征图上的 Y 坐标（浮点）
                        y = y1 + iy * bin_h + (sy + 0.5) * bin_h / sample_h
                        # 计算当前采样点在特征图上的 X 坐标（浮点）
                        x = x1 + ix * bin_w + (sx + 0.5) * bin_w / sample_w

                        # 计算双线性插值的四个像素点索引（左上、右上、左下、右下）
                        y0 = torch.floor(y)  # 上边界索引
                        x0 = torch.floor(x)  # 左边界索引
                        y1p = y0 + 1  # 下边界索引
                        x1p = x0 + 1  # 右边界索引

                        # 计算双线性插值的权重
                        wy = y - y0  # Y 方向的插值权重
                        wx = x - x0  # X 方向的插值权重
                        w00 = (1 - wy) * (1 - wx)  # 左上角的权重
                        w01 = (1 - wy) * wx        # 右上角的权重
                        w10 = wy * (1 - wx)        # 左下角的权重
                        w11 = wy * wx              # 右下角的权重

                        # 将浮点索引限制在合法范围，并转为整数索引
                        y0 = y0.clamp(0, H - 1).long()
                        x0 = x0.clamp(0, W - 1).long()
                        y1p = y1p.clamp(0, H - 1).long()
                        x1p = x1p.clamp(0, W - 1).long()

                        f = features[batch_idx]  # 当前 RoI 对应图像的特征图，形状 [C, H, W]

                        # 对四个邻近像素进行双线性加权求和，得到插值结果
                        val = (
                            w00 * f[:, y0, x0] +
                            w01 * f[:, y0, x1p] +
                            w10 * f[:, y1p, x0] +
                            w11 * f[:, y1p, x1p]
                        )  # 插值后的特征值 [C]
                        samples.append(val)  # 加入当前采样结果

                samples = torch.stack(samples, dim=0)  # 将当前 bin 的所有采样值堆叠为 [sample_h * sample_w, C]
                output[i, :, iy, ix] = samples.mean(dim=0)  # 对每个 bin 进行平均池化后写入输出

    return output  # 返回所有 RoI 的输出结果


# 测试代码段：测试反向传播是否正常
if __name__ == "__main__":
    feat = torch.randn(1, 3, 64, 64, requires_grad=True)  # 构造输入特征图，并启用梯度计算
    rois = torch.tensor([[0, 10, 10, 30, 30], [0, 20, 20, 40, 40]], dtype=torch.float32)  # 定义两个 RoI

    # 调用 RoI Align 函数进行前向计算
    out = roi_align_autograd(feat, rois, output_size=(7, 7), spatial_scale=1.0, sampling_ratio=2)

    # 定义损失函数为输出的所有值之和
    loss = out.sum()
    loss.backward()  # 执行反向传播

    print(feat.grad.shape)  # 查看梯度是否成功反传，打印特征图的梯度形状，预期 [1, 3, 64, 64]
    # ### 🔍 总结
    # | 特性   | 实现方式                        |
    # | ---- | --------------------------- |
    # | 自动求导 | 使用 PyTorch Tensor 计算，不打断计算图 |
    # | 插值方式 | 双线性插值（显式实现）                 |
    # | 池化方式 | 每个 bin 中采样点均值（平均池化）         |
    # | 可微   | 是，适合用于训练                    |
    # 如需实现 `max pooling` 版本或集成进 `nn.Module` 类结构，也可继续扩展。
    # 是否需要我将其封装成模块形式并支持批量处理？


# ---------------------------------------------------------------------------------------------------------------------
# 在上述的基础上加上可视化
import torch
import torch.nn.functional as F
import matplotlib.pyplot as plt
import numpy as np

def generate_noisy_feature_map(size=(64, 64), noise_level=5.0):
    H, W = size
    feat = torch.rand(H, W) * noise_level
    return feat.unsqueeze(0).unsqueeze(0)  # [1, 1, H, W]

def generate_synthetic_feature_map(size=(64, 64), pattern='gradient'):
    H, W = size
    if pattern == 'gradient':
        y = torch.linspace(0, 1, H).unsqueeze(1)
        x = torch.linspace(0, 1, W).unsqueeze(0)
        feat = (y + x) / 2
    elif pattern == 'center':
        y = torch.arange(H).unsqueeze(1)
        x = torch.arange(W).unsqueeze(0)
        cx, cy = W // 2, H // 2
        feat = torch.exp(-((x - cx)**2 + (y - cy)**2) / (2 * (H // 4)**2))
    elif pattern == 'checker':
        feat = (((torch.arange(H).unsqueeze(1) // 8) + (torch.arange(W).unsqueeze(0) // 8)) % 2).float()
    else:
        raise ValueError('Unsupported pattern')
    return feat.unsqueeze(0).unsqueeze(0)  # [1, 1, H, W]


def roi_pooling_pure(features, rois, output_size=(7, 7), spatial_scale=1.0):
    num_rois = rois.shape[0]
    C = features.shape[1]
    output = torch.zeros((num_rois, C, output_size[0], output_size[1]), dtype=features.dtype, device=features.device)

    for i in range(num_rois):
        batch_idx, x1, y1, x2, y2 = rois[i]
        x1 = x1 * spatial_scale
        y1 = y1 * spatial_scale
        x2 = x2 * spatial_scale
        y2 = y2 * spatial_scale

        roi_width = max(x2 - x1, 1.0)
        roi_height = max(y2 - y1, 1.0)

        bin_size_w = roi_width / output_size[1]
        bin_size_h = roi_height / output_size[0]

        for ph in range(output_size[0]):
            for pw in range(output_size[1]):
                start_x = int(torch.floor(x1 + pw * bin_size_w))
                end_x = int(torch.ceil(x1 + (pw + 1) * bin_size_w))
                start_y = int(torch.floor(y1 + ph * bin_size_h))
                end_y = int(torch.ceil(y1 + (ph + 1) * bin_size_h))

                start_x = min(max(start_x, 0), features.shape[3])
                end_x = min(max(end_x, 0), features.shape[3])
                start_y = min(max(start_y, 0), features.shape[2])
                end_y = min(max(end_y, 0), features.shape[2])

                if start_x >= end_x or start_y >= end_y:
                    pooled_val = torch.zeros(C, device=features.device)
                else:
                    region = features[int(batch_idx), :, start_y:end_y, start_x:end_x]
                    pooled_val = torch.max(region.reshape(C, -1), dim=1)[0]
                output[i, :, ph, pw] = pooled_val
    return output


def bilinear_interpolate_torch(im, x, y):
    C, H, W = im.shape
    x = x.clamp(0, W - 1 - 1e-6)
    y = y.clamp(0, H - 1 - 1e-6)

    x0 = torch.floor(x).long()
    x1 = x0 + 1
    y0 = torch.floor(y).long()
    y1 = y0 + 1

    x1 = x1.clamp(max=W - 1)
    y1 = y1.clamp(max=H - 1)

    wa = (x1.float() - x) * (y1.float() - y)
    wb = (x1.float() - x) * (y - y0.float())
    wc = (x - x0.float()) * (y1.float() - y)
    wd = (x - x0.float()) * (y - y0.float())

    # 逐通道索引：
    val = torch.zeros_like(x)
    for c in range(C):
        Ia = im[c, y0[c], x0[c]]
        Ib = im[c, y1[c], x0[c]]
        Ic = im[c, y0[c], x1[c]]
        Id = im[c, y1[c], x1[c]]
        val[c] = wa[c] * Ia + wb[c] * Ib + wc[c] * Ic + wd[c] * Id

    return val


def roi_align_pure(features, rois, output_size=(7, 7), spatial_scale=1.0, sampling_ratio=2):
    num_rois = rois.shape[0]
    C = features.shape[1]
    output = torch.zeros((num_rois, C, output_size[0], output_size[1]), dtype=features.dtype, device=features.device)

    for i in range(num_rois):
        batch_idx, x1, y1, x2, y2 = rois[i]
        x1 = x1 * spatial_scale
        y1 = y1 * spatial_scale
        x2 = x2 * spatial_scale
        y2 = y2 * spatial_scale

        roi_width = max(x2 - x1, 1.0)
        roi_height = max(y2 - y1, 1.0)

        bin_size_w = roi_width / output_size[1]
        bin_size_h = roi_height / output_size[0]

        for ph in range(output_size[0]):
            for pw in range(output_size[1]):
                n_samples = sampling_ratio
                if n_samples > 0:
                    sample_x = x1 + pw * bin_size_w + (torch.arange(n_samples, dtype=torch.float32, device=features.device) + 0.5) * (bin_size_w / n_samples)
                    sample_y = y1 + ph * bin_size_h + (torch.arange(n_samples, dtype=torch.float32, device=features.device) + 0.5) * (bin_size_h / n_samples)
                else:
                    sample_x = torch.tensor([x1 + (pw + 0.5) * bin_size_w], device=features.device)
                    sample_y = torch.tensor([y1 + (ph + 0.5) * bin_size_h], device=features.device)

                sample_x = sample_x.unsqueeze(0).repeat(C, 1)  # [C, n_samples]
                sample_y = sample_y.unsqueeze(0).repeat(C, 1)  # [C, n_samples]

                vals = bilinear_interpolate_torch(features[int(batch_idx)], sample_x, sample_y)  # [C, n_samples]
                output[i, :, ph, pw] = vals.mean(dim=1)
    return output


def visualize_roi_results(feats, rois, out_pool, out_align):
    feat_np = feats[0, 0].cpu().numpy()
    plt.figure(figsize=(16, 5))

    plt.subplot(1, 4, 1)
    plt.title("Original Feature Map")
    plt.imshow(feat_np, cmap='viridis')
    for roi in rois:
        batch_idx, x1, y1, x2, y2 = roi
        rect = plt.Rectangle((x1, y1), x2 - x1, y2 - y1,
                             fill=False, edgecolor='r', linewidth=2)
        plt.gca().add_patch(rect)
    plt.colorbar()

    plt.subplot(1, 4, 2)
    plt.title("RoI Pooling Output")
    plt.imshow(out_pool[0, 0].cpu().numpy(), cmap='viridis')
    plt.colorbar()

    plt.subplot(1, 4, 3)
    plt.title("RoI Align Output")
    plt.imshow(out_align[0, 0].cpu().numpy(), cmap='viridis')
    plt.colorbar()

    plt.subplot(1, 4, 4)
    plt.title("Difference (Align - Pool)")
    diff = (out_align - out_pool)[0, 0].cpu().numpy()
    plt.imshow(diff, cmap='bwr', vmin=-diff.max(), vmax=diff.max())
    plt.colorbar()

    plt.tight_layout()
    plt.show()


def visualize_error_heatmap(out_pool, out_align):
    diff = (out_align - out_pool).abs()[0, 0].cpu().numpy()
    plt.figure(figsize=(5, 4))
    plt.title("Absolute Difference Heatmap")
    plt.imshow(diff, cmap='hot')
    plt.colorbar()
    plt.show()


if __name__ == "__main__":
    feats = generate_noisy_feature_map(noise_level=5.0)  # 噪声高，增强差异
    # feats = generate_synthetic_feature_map(pattern='gradient')  # 'gradient' | 'center' | 'checker'
    print("features shape:", feats.shape)  # 一定是 [1,1,H,W]

    rois = torch.tensor([
        [0, 30.0, 30.0, 35.0, 35.0],  # 5x5小区域
    ])
    # rois = torch.tensor([
    #     [0, 10.0, 10.0, 50.0, 50.0]
    # ])
    # rois = torch.tensor([
    #     [0, 5.0, 5.0, 20.0, 20.0],
    #     [0, 15.0, 15.0, 35.0, 35.0],
    #     [0, 25.0, 25.0, 45.0, 45.0],
    # ])

    out_pool = roi_pooling_pure(feats, rois, output_size=(7, 7), spatial_scale=1.0)
    print("out_pool Output shape:", out_pool.shape)

    out_align = roi_align_pure(feats, rois, output_size=(7, 7), spatial_scale=1.0, sampling_ratio=2)
    print("roi_align_pure Output shape:", out_align.shape)

    visualize_roi_results(feats, rois, out_pool, out_align)
    visualize_error_heatmap(out_pool, out_align)

# 下面是一个完整示例，展示如何将 `RoI Align` 的输出插值（上采样）回原图对应区域大小，用于可视化或 mask 操作。这个过程通常出现在像 **Mask R-CNN** 的分支中：
#
# ---
#
# ### ✅ 示例：RoI Align 后上采样回原图大小区域
#
# ```python
# import torch
# import torch.nn.functional as F
# import torchvision.ops as ops
# import matplotlib.pyplot as plt
#
# # 原始输入图像大小
# img_h, img_w = 224, 224
#
# # 模拟 CNN 提取的特征图大小，假设为 1/16 缩小
# feat_h, feat_w = img_h // 16, img_w // 16
# features = torch.randn(1, 256, feat_h, feat_w)
#
# # 假设输入的 RoI 在原图尺度：[batch_idx, x1, y1, x2, y2]
# rois = torch.tensor([[0, 50, 60, 150, 160]], dtype=torch.float)
#
# # 定义 spatial_scale
# spatial_scale = 1.0 / 16
#
# # 执行 RoI Align，输出固定尺寸（例如 14×14）
# roi_feat = ops.roi_align(features, rois, output_size=(14, 14), spatial_scale=spatial_scale)
#
# # 将 RoI 回到原图上的区域大小（150-50, 160-60）→ (100, 100)
# roi_size = (int(rois[0, 4] - rois[0, 2]), int(rois[0, 3] - rois[0, 1]))  # 高、宽
#
# # 插值放大 RoI 特征
# roi_upsampled = F.interpolate(roi_feat, size=roi_size, mode='bilinear', align_corners=False)
#
# # 可视化（选第一个通道）
# import matplotlib.pyplot as plt
# plt.imshow(roi_upsampled[0, 0].detach().cpu(), cmap='viridis')
# plt.title('Upsampled RoI Feature (Channel 0)')
# plt.colorbar()
# plt.show()
# ```
#
# ---
#
# ### 🔍 总结流程
#
# | 步骤                | 说明                                               |
# | ----------------- | ------------------------------------------------ |
# | 1️⃣ 原图坐标 → 特征图坐标  | RoI `[x1, y1, x2, y2]` 乘以 `spatial_scale`        |
# | 2️⃣ 从特征图中提取特征块    | 用 `roi_align` 取出 14×14 的 patch                   |
# | 3️⃣ 放大成原图区域大小     | 用 `F.interpolate` 将 14×14 → `(x2 - x1, y2 - y1)` |
# | 4️⃣ 可用于 mask、可视化等 | 如显示掩码、或融合回原图                                     |
#
# ---
#
# 如需我扩展成批量操作、多通道展示、或嵌入 Mask R-CNN 分支，请告诉我，我可以写出完整实现。需要我将这个插值回原图区域的过程也加入你当前的 Canvas 文档吗？

# ---------------------------------------------------------------------------------------------------------------------
# 函数方法
import torch  # 导入PyTorch库
import torchvision.ops as ops  # 导入torchvision中的操作模块，用于调用官方的RoI操作

# 假设特征图大小为[1, 256, 56, 56]
features = torch.rand(1, 256, 56, 56).float()  # 随机生成一个张量，模拟Batch=1, Channels=256, Height=56, Width=56的特征图

# 假设RoIs为[batch_index, x1, y1, x2, y2]
# 其中batch_index表示RoI所在的图像在batch中的索引
rois = torch.tensor([[0, 10, 10, 50, 50], [0, 20, 20, 40, 40]]).float()  # 定义两个RoI，每个RoI包含5个值并转换为float类型

# 定义RoI Align的参数
output_size = (7, 7)  # 输出特征图的大小，高和宽均为7
spatial_scale = 1.0 / 16  # 特征图相对于原图的缩放比例，假设下采样16倍

# 执行RoI Align操作
torch_roi_output = ops.roi_align(
    features,        # 输入特征图
    rois,            # RoIs列表
    output_size,     # 输出特征图大小
    spatial_scale    # 缩放比例
)
print(torch_roi_output.shape)  # 打印输出结果的shape，预期[2, 256, 7, 7]


# 自定义RoI Align方法实现
import torch
import torch.nn.functional as F  # 导入函数式API，用于插值和池化操作

def roi_align(x, rois, output_size, spatial_scale=1.0, sampling_ratio=-1):
    # 将感兴趣区域（ROI）坐标从原图尺度转换到特征图尺度
    rois = rois / spatial_scale
    # 向上取整，保证RoI右下角完全覆盖
    rois[:, 2:] = torch.ceil(rois[:, 2:])
    # 向下取整，保证RoI左上角完全覆盖
    rois[:, :2] = torch.floor(rois[:, :2])
    # 转换为整数型坐标
    rois = rois.int()
    roi_features = []  # 用于存储每个RoI的输出特征
    for roi in rois:
        # 从x中裁剪出RoI区域，roi格式为[x1, y1, x2, y2]
        x_ = x[..., roi[1]:roi[3], roi[2]:roi[4]]  # 注意索引顺序batch和channel保留
        h, w = x_.shape[-2:]  # 获取裁剪后特征的高和宽
        if sampling_ratio > 0:
            # 如果指定了采样率，则对裁剪后的特征进行双线性插值
            x_ = F.interpolate(
                x_, size=(sampling_ratio * h, sampling_ratio * w),
                mode='bilinear', align_corners=False
            )
        # 对插值后的特征进行自适应最大池化，输出output_size
        roi_feature = F.adaptive_max_pool2d(x_, output_size)
        roi_features.append(roi_feature)  # 将结果加入列表
    # 将所有RoI特征按照batch维度拼接
    return torch.cat(roi_features, dim=0)

# 测试自定义roi_align函数
feature_map = torch.randn(1, 3, 64, 64)  # 随机生成[1,3,64,64]特征图
rois = torch.tensor([[0, 10, 10, 50, 50], [0, 20, 20, 40, 40]])  # 定义两个RoI
output_size = (7, 7)  # 指定输出大小
custom_output = roi_align(feature_map, rois, output_size, sampling_ratio=5)  # 采样率为5
print(custom_output.shape)  # 打印shape，预期[2,3,7,7]


# 自定义RoI Pooling方法实现
import torch
import torch.nn.functional as F

def roi_pooling(inputs, rois, output_size):
    # inputs: [batch_size, channels, height, width]
    # rois: [num_proposals, 5] (batch_index, x1, y1, x2, y2)
    # output_size: (out_h, out_w)

    # 转置RoIs以便拆分批次索引和坐标
    rois = rois.t()  # 变为[5, num_proposals]
    batch_ids = rois[0].long()  # 提取batch索引并转换为long类型
    # 将归一化坐标转换到特征图尺寸
    roi_start_w = rois[1] * inputs.size(3)
    roi_start_h = rois[2] * inputs.size(2)
    roi_end_w = rois[3] * inputs.size(3)
    roi_end_h = rois[4] * inputs.size(2)

    pooled = []  # 用于存放每个batch的池化结果
    # 遍历每个图像batch
    for i in range(inputs.size(0)):
        # 找到属于当前batch的RoIs
        mask = batch_ids == i
        if mask.sum() == 0:
            # 如果当前batch没有RoIs，返回空张量
            pooled.append(torch.zeros(0, inputs.size(1), output_size[0], output_size[1], device=inputs.device))
            continue
        # 选出当前batch的RoIs坐标
        start_w = roi_start_w[mask]
        start_h = roi_start_h[mask]
        end_w = roi_end_w[mask]
        end_h = roi_end_h[mask]

        # 按输出大小将特征图划分网格，并将坐标映射到网格索引
        grid_h = inputs.size(2) // output_size[0]
        grid_w = inputs.size(3) // output_size[1]
        # 计算RoI在网格上的起止格子索引，并转换为int
        grid_start_w = (start_w / grid_w).floor().clamp(0, inputs.size(3)-1).long()
        grid_start_h = (start_h / grid_h).floor().clamp(0, inputs.size(2)-1).long()
        grid_end_w = (end_w / grid_w).ceil().clamp(1, inputs.size(3)).long()
        grid_end_h = (end_h / grid_h).ceil().clamp(1, inputs.size(2)).long()

        # 提取当前batch的特征图
        feat = inputs[i]
        # 对每个RoI按网格大小进行最大池化
        rois_features = []
        for sw, sh, ew, eh in zip(grid_start_w, grid_start_h, grid_end_w, grid_end_h):
            region = feat[:, sh:eh, sw:ew]  # 裁剪网格内特征
            pooled_feature = F.adaptive_max_pool2d(region.unsqueeze(0), output_size)  # 自适应池化到output_size
            rois_features.append(pooled_feature)
        # 拼接当前batch所有RoI的池化结果
        pooled.append(torch.cat(rois_features, dim=0))
    # 将所有batch结果堆叠为一个张量
    return torch.cat(pooled, dim=0)

# 测试自定义roi_pooling函数
inputs = torch.randn(2, 3, 64, 64)  # Batch=2, Channels=3, H=W=64
rois = torch.tensor([[0, 0.1, 0.1, 0.5, 0.5], [1, 0.2, 0.2, 0.4, 0.4]])  # 归一化坐标定义
output_size = (7, 7)  # 输出大小
pool_output = roi_pooling(inputs, rois, output_size)
print(pool_output.shape)  # 打印shape，预期[2,3,7,7]
