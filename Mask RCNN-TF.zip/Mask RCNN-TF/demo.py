import numpy as np
import tensorflow as tf

# # 假设我们有 2 个样本，每个样本有 3 个类别的信息
# # rpn_class_logits
# rpn_class_logits = np.array([[0.1, 0.2, 0.3],
#                                [0.4, 0.5, 0.6]])
#
# # rpn_class
# rpn_class = np.array([[1, 0, 1],
#                       [0, 1, 1]])
#
# # rpn_bbox (假设这里的最后一维是 4 用于边界框的 4 个坐标)
# rpn_bbox = np.array([[[0, 1, 2, 3],
#                       [1, 2, 3, 4],
#                       [2, 3, 4, 5]],
#                      [[3, 4, 5, 6],
#                       [4, 5, 6, 7],
#                       [5, 6, 7, 8]]])
#
# # 在 axis=1 上进行拼接
# combined_class_logits = np.concatenate((rpn_class_logits, rpn_class), axis=1)
# print("Combined Class Logits:\n", combined_class_logits, '\n')
# print("Combined Class Logits Shape:", combined_class_logits.shape)  # 应该是 (2, 6)
#
# combined_bbox = rpn_bbox.reshape(2, -1, 4)  # 变形以在第二个维度合并
# print("Combined BBox:\n", combined_bbox, '\n')
# print("Combined BBox Shape:", combined_bbox.shape)  # 应该是 (2, 9, 4)



# # 定义 batch_slice 函数
# def batch_slice(inputs, graph_fn, batch_size, names=None):
#     if not isinstance(inputs, list):
#         inputs = [inputs]
#
#     outputs = []
#     for i in range(batch_size):
#         inputs_slice = [x[i] for x in inputs]  # 获取每个批次的数据切片
#         output_slice = graph_fn(*inputs_slice)  # 调用 graph_fn 处理切片
#
#         if not isinstance(output_slice, (tuple, list)):  # 如果返回的是单个张量，转换为列表
#             output_slice = [output_slice]
#
#         outputs.append(output_slice)
#
#     outputs = list(zip(*outputs))  # 转置输出，方便堆叠
#     if names is None:
#         names = [None] * len(outputs)
#
#     result = [tf.stack(o, axis=0, name=n) for o, n in zip(outputs, names)]
#
#     if len(result) == 1:  # 如果只有一个输出，返回单个张量
#         result = result[0]
#
#     return result
#
#
# # 示例1：graph_fn 返回单个张量
# def example_single_output():
#     # 输入两个张量
#     input_tensor1 = tf.constant([[1, 2], [3, 4]], dtype=tf.float32)  # shape (2, 2)
#     input_tensor2 = tf.constant([[0, 1], [1, 0]], dtype=tf.int32)  # shape (2, 2)
#
#     # 定义 graph_fn，返回单个张量
#     graph_fn = lambda x, y: tf.gather(x, y)
#
#     # 使用 batch_slice 处理，batch_size=2
#     result = batch_slice([input_tensor1, input_tensor2], graph_fn, batch_size=1)
#     # result = batch_slice([input_tensor1, input_tensor2], graph_fn, batch_size=2)
#
#     # 打印结果
#     print("Single output result:", result)
#
#
# # 示例2：graph_fn 返回多个张量
# def example_multiple_outputs():
#     # 输入两个张量
#     input_tensor1 = tf.constant([[1, 2], [3, 4]], dtype=tf.float32)  # shape (2, 2)
#     input_tensor2 = tf.constant([[0, 1], [1, 0]], dtype=tf.int32)  # shape (2, 2)
#
#     # 定义 graph_fn，返回多个张量
#     graph_fn = lambda x, y: (tf.gather(x, y), tf.reduce_sum(x))
#
#     # 使用 batch_slice 处理，batch_size=2
#     result = batch_slice([input_tensor1, input_tensor2], graph_fn, batch_size=2)
#
#     # 打印结果
#     print("Multiple outputs result:", result)
#
#
# # 运行示例
# example_single_output()
# example_multiple_outputs()


# # 定义简单的输入张量
# input_tensor1 = tf.constant([[1, 2], [3, 4]], dtype=tf.float32)
# input_tensor2 = tf.constant([[0, 1], [1, 0]], dtype=tf.int32)
#
#
# # 定义一个简单的 graph_fn 函数，执行 gather 操作
# def graph_fn(x, y):
#     return tf.gather(x, y)
#
#
# # 模拟 batch_slice 的操作
# batch_size = 2  # 有两个批次
# outputs = []
# for i in range(batch_size):
#     # 逐批次获取数据切片
#     x_slice = input_tensor1[i]
#     y_slice = input_tensor2[i]
#
#     # 调用 graph_fn 处理每个切片
#     output_slice = graph_fn(x_slice, y_slice)
#
#     # 将结果加入 outputs 列表
#     outputs.append(output_slice)
#
# # 最终将所有批次的结果堆叠起来
# final_result = tf.stack(outputs, axis=0)
#
# # 打印结果
# print("Final stacked result:", final_result)

# # 创建一个源张量 (2D Tensor)
# params = tf.constant([[10,20,30],
#                      [40,50,60],
#                      [70,80,90],
#                      [100,110,120]])
#
# # 指定要提取的行索引
# indices = tf.constant([1,3])
# # 提取索引为1 和3 的行# 使用 tf.gather 提取指定的行
# result = tf.gather(params, indices)
#
# # 使用 Session计算结果
# with tf.compat.v1.Session() as sess:
#      params_val = sess.run(params)
#      result_val = sess.run(result)
#
# # 输出结果print("源张量:\n", params_val)
# print("提取的行:\n", result_val)

# '''
# 在深度学习和数据处理领域中，`batch_slice` 通常指的是从一个批量数据（batch of data）中按特定方式（如索引、切片等）提取子集的操作。
#
# ### `batch_slice` 的中文翻译- **中文翻译**: `batch_slice` 可以翻译为“批量切片”或“批处理切片”。它表示对一组数据（通常是一个批次）进行切片操作。
#
# ### 关于 `slice` 对象在 Python 中，`slice` 对象是用来表示切片操作的内置类型，它允许我们使用 `start:stop:step` 的形式定义切片。通过 `slice` 对象，我们可以在序列类型（如列表、元组、字符串等）中提取特定范围的元素。
#
# ### 示例：使用 `slice` 对象以下是一个简单的示例，展示如何使用 `slice` 对象：
#
# ```python# 创建一个列表data = [0,1,2,3,4,5,6,7,8,9]
#
# # 使用 slice 对象进行切片slice_obj = slice(2,8,2) # 从索引2 到索引8，每隔2 个元素sliced_data = data[slice_obj]
#
# print("原始数据:", data)
# print("切片结果:", sliced_data)
# ```
#
# ### 输出结果```
# 原始数据: [0,1,2,3,4,5,6,7,8,9]
# 切片结果: [2,4,6]
# ```
#
# 在这个示例中，我们使用 `slice` 对象来获取原始列表中的特定切片。你可以通过 `slice` 对象方便地定义切片范围，而无需直接使用 `start:stop:step`语法。
#
# ### 总结- `batch_slice` 表示对批量数据进行切片的操作，通常用于提取部分数据。
# - Python 中的 `slice` 对象提供了一种灵活的方式来定义切片，允许更复杂的切片操作。
# '''
# # 数据
# data = [0,1,2,3,4,5,6,7,8,9]
# # 使用 slice 对象进行切片
# slice_obj = slice(2,8,2)
# # 从索引2 到索引8，每隔2 个元素
# sliced_data = data[slice_obj]
#
# print("原始数据:", data)
# print("切片结果:", sliced_data)

# '''
# 在 TensorFlow1.x（如1.15版本）中，确实有一些情况需要使用字典，但对于单个变量的情况，您一般可以直接使用该变量，而不需要将其放入字典中。让我们分别讨论如何在 TensorFlow1.x 中处理单个变量和多个变量。
#
# ### 单个变量如果您只需要创建和操作单个变量，您可以直接使用该变量，例如：
#
# ```pythonimport tensorflow as tf# 创建一个常量张量value = tf.constant(42.0)
#
# # 在会话中运行以获取值with tf.Session() as sess:
#  print(sess.run(value)) # 输出:42.0```
#
# 在这个例子中，您不需要使用字典来传递单个变量。
#
# ### 多个变量当涉及多个变量时，虽然不一定需要使用字典，您可以选择传递多个张量作为函数参数。例如：
#
# ```python
# import tensorflow as tf# 创建常量张量a = tf.constant(5)
# b = tf.constant(3)
#
# # 定义一个加法操作的计算图result = tf.add(a, b)
#
# # 在会话中运行计算以获取结果with tf.Session() as sess:
#  print(sess.run(result)) # 输出:8```
#
# ### 使用字典的情况您使用字典的情况通常出现在以下情形：
#
# 1. **使用占位符时**: 在 TensorFlow1.x 中，如果要通过占位符传递变量，通常会使用字典。例如，您定义了一个占位符，并希望在执行时给它一个值。
#
#  ```python x = tf.placeholder(tf.float32)
#  y = tf.add(x,5)
#
#  with tf.Session() as sess:
#  print(sess.run(y, feed_dict={x:10})) # 输出:15 ```
#
# 在这种情况下，由于 `x` 是一个占位符，所以您需要通过 `feed_dict` 来传递数据。
#
# ### 总结- 对于单个常量或变量，您可以直接使用，而不需要使用字典。
# - 对于占位符，您需要使用字典（通过 `feed_dict`）来传递数据。
# - 在大多数情况下，可以直接使用张量对象，而不是特别依赖字典，除非涉及到占位符或更复杂的图结构。
#
# 为什么要传字典？
# 在 TensorFlow1.x 中，使用字典传递数据主要是为了处理占位符变量。占位符（placeholder）用于在计算图中定义输入，如果在执行图时希望动态修改这些输入的值，就需要使用字典。让我们详细了解一下这种机制。
#
# ### 占位符的概念在 TensorFlow1.x 中，`tf.placeholder` 用于定义一个张量变量，其值在运行时提供，而不是在图构建时固定。这种方式使得同一个计算图可以在不同的运行中使用不同的数据输入。
#
# ### 为什么要使用字典占位符在构建计算图时并不具有具体的值，它们只是占位符。为了在执行图时给这些占位符分配具体的值，您需要使用 `feed_dict` 参数，它是一个字典，用于将实际的值映射到占位符上。
#
# ### 示例以下是一个简单的示例，展示了如何在 TensorFlow1.x 中使用占位符和字典：
#
# ```python
# import tensorflow as tf# 定义占位符x = tf.placeholder(tf.float32)
# y = tf.placeholder(tf.float32)
#
# # 定义操作，例如加法z = x + y
# # 创建一个 TensorFlow 会话
# with tf.Session() as sess:
#  # 使用 feed_dict传递具体的值 result = sess.run(z, feed_dict={x:10, y:15})
#  print(result) # 输出:25```
#
# ### 总结- **动态输入**: 占位符允许在运行时动态输入数据，因此您不需要在构建计算图时就为所有可能的输入值提供静态数据。
# - **字典的用途**:通过 `feed_dict` 使用字典，可以方便地将不同的值传递给多个占位符，从而动态控制计算的输入。
#
# 使用字典的关键在于，它提供了一种优雅的方式来将运行时数据与计算图中定义的占位符关联起来，让您能够灵活地构建和使用模型。
#
# 没有占位符就直接一个向量传进去sees.run？
# 是的，在 TensorFlow1.x 中，如果您没有使用占位符，而是直接定义了常量或变量，您可以直接将这些值传递给 `sess.run()` 函数，而不需要使用 `feed_dict` 或字典。这使得您可以以更简单的方式运行计算。
#
# ### 示例以下是直接传递一个张量的简单示例：
#
# ```pythonimport tensorflow as tf# 创建一个常量张量a = tf.constant([1,2,3], dtype=tf.float32) # 定义一个向量# 定义一个操作，例如计算平方squared = tf.square(a)
#
# # 创建一个 TensorFlow 会话with tf.Session() as sess:
#  result = sess.run(squared) #直接运行计算 print(result) # 输出: [1.4.9.]
# ```
#
# 在这个例子中：
# - `a` 是一个常量张量。
# - `squared` 是对 `a`进行平方运算的操作。
# - 在 `sess.run(squared)` 中，您可以直接传递 `squared`，它会返回计算结果。
#
# ### 总结如果是常量或已经定义的变量，您可以将它们作为参数直接传递给 `sess.run()`，而不必使用字典。如果涉及到占位符，则需要使用 `feed_dict` 将运行时的输入值传递进去。
#
# '''
# # 高度（height）：200 像素- 宽度（width）：300 像素- 通道数（channels）：3（例如 RGB 图像）
# image_shape = tf.constant([200,300,3], dtype=tf.int32)
#
# #计算图像面积
# image_area = tf.cast(image_shape[0] * image_shape[1], tf.float32)
#
# # 输出结果
# print(image_area)
#
# ### TensorFlow1.x如果你使用的是 TensorFlow1.x，那么你需要在一个 TensorFlow 会话中运行计算，如下所示：
#
# # 在会话中运行图形
# with tf.Session() as sess:
#     result = sess.run(image_area)
#     print(result) # 输出:60000.0```


# # 在 TensorFlow1.x 中，对于复杂的计算图，您仍然使用 `sess.run()` 来执行图中的操作。创建复杂计算图的过程通常涉及定义多个操作和变量，以及将它们组合在一起。以下是一些常用的策略和步骤，帮助您在复杂计算图中有效地使用 `sess.run()`。
# ###1. 创建计算图您可以定义变量、常量、占位符和操作，以构建复杂的计算图。例如，您可能需要多个层次的神经网络或多个操作串联在一起。
#
# ### 示例：构建复杂计算图```pythonimport tensorflow as tf# 输入占位符
# x = tf.placeholder(tf.float32, shape=[None,2]) # 假设输入为二维向量# 定义权重和偏置
# weights = tf.Variable(tf.random_normal([2,1]), name='weights')
# #2x1 权重矩阵
# bias = tf.Variable(tf.zeros([1]), name='bias')
# # 偏置
# # 定义线性模型
# linear_model = tf.matmul(x, weights) + bias
# # 定义损失函数，例如均方误差
# y_true = tf.placeholder(tf.float32, shape=[None,1])
# #真实值
# loss = tf.reduce_mean(tf.square(linear_model - y_true))
#
# # 定义优化器
# optimizer = tf.train.GradientDescentOptimizer(learning_rate=0.01)
# train = optimizer.minimize(loss)
#
# # 初始化变量
# init = tf.global_variables_initializer()
#
# ###2. 在会话中运行计算在会话中，您可以使用 `sess.run()` 来执行计算。您需要结合使用 `feed_dict` 来为占位符传递实际的输入值。以下是如何运行上述计算图的示例：
#
# # 创建一个 TensorFlow 会话
# with tf.Session() as sess:
#     # 初始化变量
#     sess.run(init)
#
#      # 假设有一些训练数据
#     x_train = [[1,2], [2,3], [3,4]]
#     y_train = [[1], [2], [3]] #期望输出 #训练模型
#     for epoch in range(100):
#         _, current_loss = sess.run([train, loss], feed_dict={x: x_train, y_true: y_train})
#         print(f'Epoch {epoch +1}, Loss: {current_loss}')
#
#     #预测
#     predictions = sess.run(linear_model, feed_dict={x: [[1,2], [2,3]]})
#     print(predictions)

### 小结-通过定义计算图中的变量、操作和占位符来构建复杂的计算图。
# - 使用 `sess.run()` 执行图中的操作，通常会结合 `feed_dict` 来传入占位符的实际值。
# - 您可以在 `sess.run()` 中同时运行多个操作，例如同时训练模型和计算损失值。
#
# 通过这种方式，您可以会话中执行复杂的计算图，并利用 TensorFlow1.x 的特性来进行模型训练和推断。



# 在 TensorFlow1.x 中，如果您不使用 `feed_dict`传递输入，即不使用占位符，而是直接使用常量或变量，那么您的计算图通常不需要动态输入。相应地，您可以创建常量或变量并直接在 `sess.run()` 中传递它们的张量。以下是如何处理复杂计算图的示例而不使用字典。
#
# ### 示例：使用常量和变量构建复杂计算图假设您构建了一个简单的线性回归模型，使用常量和变量而不涉及占位符。
#
# ```python
# import tensorflow as tf# 定义输入数据（用常量表示）
# x_train = tf.constant([[1.0,2.0], [2.0,3.0], [3.0,4.0]], dtype=tf.float32)
# y_train = tf.constant([[1.0], [2.0], [3.0]], dtype=tf.float32)
#
# # 定义权重和偏置（用变量表示）
# weights = tf.Variable(tf.random_normal([2,1]), name='weights') #2x1 权重矩阵bias = tf.Variable(tf.zeros([1]), name='bias') # 偏置# 定义线性模型linear_model = tf.matmul(x_train, weights) + bias# 定义损失函数，例如均方误差loss = tf.reduce_mean(tf.square(linear_model - y_train))
#
# # 定义优化器optimizer = tf.train.GradientDescentOptimizer(learning_rate=0.01)
# train = optimizer.minimize(loss)
#
# # 初始化变量init = tf.global_variables_initializer()
# ```
#
# ###运行计算图接下来，您可以在会话中运行计算，直接运行损失和训练步骤，而不需要使用 `feed_dict`。
#
# ```python# 创建一个 TensorFlow 会话with tf.Session() as sess:
#  # 初始化变量 sess.run(init)
#
#  #训练模型 for epoch in range(100):
#  _, current_loss = sess.run([train, loss]) # 不使用 feed_dict，此时 using直接传入常量 print(f'Epoch {epoch +1}, Loss: {current_loss}')
#
#  #预测 predictions = sess.run(linear_model) #仍然可以直接调用 print(predictions)
# ```
#
# ### 总结- **常量和变量**: 当数据是在图中以常量或变量的形式定义时，您可以直接在 `sess.run()` 中使用这些张量。
# - **不使用字典**: 如果您的计算图不依赖于动态输入（例如使用占位符），那么您可以直接在 `sess.run()` 中运行整个计算图，而无需使用 `feed_dict`。
#
# 这种方式适用于在训练或推理过程中输入固定的数据集。如果您需要在模型运行时动态提供不同的输入，则通常需要使用占位符，并结合 `feed_dict` 来传递数据。

# # 示例：
# # 假设我们有一个 batch 大小为 2 的输入特征图，每个特征图的大小为 10x10，通道数为 3，我们有 3 个建议框需要裁剪。
# import tensorflow as tf
#
# # 假设有 2 张特征图，大小为 10x10，通道为 3
# feature_map = tf.random.normal([2, 10, 10, 3])
#
# # 有 3 个建议框，每个框由 [y1, x1, y2, x2] 表示，坐标范围 [0, 1]
# boxes = tf.constant([[0.1, 0.1, 0.5, 0.5], [0.2, 0.2, 0.6, 0.6], [0.3, 0.3, 0.7, 0.7]])
#
# # 对应的特征图索引，表示每个框是从第几张特征图提取
# box_indices = tf.constant([0, 1, 0])
#
# # 池化后的固定大小 7x7
# crop_size = [7, 7]
#
# # 使用 tf.image.crop_and_resize
# cropped_and_resized = tf.image.crop_and_resize(feature_map, boxes, box_indices, crop_size)
#
# print(cropped_and_resized.shape)  # 输出形状应为 (3, 7, 7, 3)
# # 结果形状 (3, 7, 7, 3) 表示从两张特征图中根据 3 个框裁剪出 3 个 7x7 大小的区域，通道数保持为 3。
# # 解释：
# # 输入的特征图有两张，每张大小为 10x10。
# # boxes 提供了 3 个裁剪区域，它们在特征图中按照 [y1, x1, y2, x2] 的格式给出。
# # box_indices 指定了每个框从哪一张特征图中裁剪。
# # 最后得到的结果是每个框被裁剪并调整到 7x7 大小。

import tensorflow as tf

# '''
# 解释：
# 原始的张量 tensor 形状是 (1, 3, 1, 4)，可以看到有两个维度的大小为1。
# tf.squeeze 移除了那些大小为1的维度，所以最终的张量形状变成了 (3, 4)，而张量的内容没有发生变化。
# 这使得张量在形状上变得更简洁，更容易操作，特别是在一些需要二维或三维张量的操作中非常有用。
#
# 应用场景解释：
# 在你提到的代码 roi_level = tf.squeeze(roi_level, 2) 中：
#
# roi_level 可能是一个形状为 (batch_size, num_boxes, 1) 的张量，tf.squeeze(roi_level, 2) 就是将第三个维度（即大小为1的维度）去掉，最终变成 (batch_size, num_boxes)，以便在后续处理中使用。
# tf.squeeze 就像是把数组中那些没必要占据位置的"空空间"给去掉，使得数组变得更简单、更直接。
#
# 希望这个例子帮助你理解 tf.squeeze！
# '''
# import tensorflow as tf
#
# # 创建一个形状为 (1, 3, 1, 4) 的张量，注意其中有两个维度的大小为1
# tensor = tf.constant([[[[1, 2, 3, 4]],
#                        [[5, 6, 7, 8]],
#                        [[9, 10, 11, 12]]]])
#
#
# # 使用 tf.squeeze 去掉大小为1的维度
# squeezed_tensor = tf.squeeze(tensor)
#
#
# # 启动一个 TensorFlow 会话来获取张量的值
# with tf.compat.v1.Session() as sess:
#     original_value = sess.run(tensor)
#     squeezed_value = sess.run(squeezed_tensor)
#     print("Original tensor shape:", tensor.shape)
#     print("Original tensor values:\n", original_value)
#     print('\n')
#     print("Squeezed tensor shape:", squeezed_tensor.shape)
#     print("Squeezed tensor values:\n", squeezed_value)


# # 理解稀疏张量
# # 创建稀疏张量
# indices = [[0, 0], [1, 2], [3, 4]]  # 非零元素的坐标
# values = [1, 3, 5]  # 非零元素的值
# dense_shape = [5, 5]  # 稀疏张量的形状
#
# sparse_tensor = tf.SparseTensor(indices, values, dense_shape)
#
# # 转换为密集张量
# # dense_tensor = tf.sparse.to_dense(sparse_tensor)
# dense_tensor = tf.sparse_tensor_to_dense(sparse_tensor)
# with tf.compat.v1.Session() as sess:
#     sparse_tensor_value = sess.run(sparse_tensor)
#     print("稀疏张量:\n", sparse_tensor_value)
#     print("稀疏张量shape:\n", sparse_tensor)
#
#     dense_tensor_value = sess.run(dense_tensor)
#     print("密集张量:\n", dense_tensor_value)
#     print("密集张量shape:\n", dense_tensor)

# # 练习 2: 交集计算
# # 定义两个稀疏张量
# indices_a = [[0, 1], [1, 2], [2, 3]]
# values_a = [1, 2, 3]
# dense_shape_a = [3, 4]
#
# indices_b = [[1, 2], [2, 3], [3, 4]]
# values_b = [4, 5, 6]
# dense_shape_b = [4, 5]
#
# sparse_tensor_a = tf.SparseTensor(indices_a, values_a, dense_shape_a)
# sparse_tensor_b = tf.SparseTensor(indices_b, values_b, dense_shape_b)
#
# # 转换为密集张量
# dense_a = tf.sparse_tensor_to_dense(sparse_tensor_a)
# dense_b = tf.sparse_tensor_to_dense(sparse_tensor_b)
#
# # 计算交集
# intersection = tf.sets.intersection(tf.expand_dims(sparse_tensor_a.indices, 0), tf.expand_dims(sparse_tensor_b.indices, 0))
#
# with tf.Session() as sess:
#     intersection_result = sess.run(intersection)
#     print("交集的密集张量:\n", intersection_result)

# # 练习 3: 应用场景
# # 创建稀疏张量表示学生成绩
# student_indices = [[0, 0], [1, 2], [2, 4]]  # 学生编号
# student_values = [85, 90, 75]  # 学生成绩
# student_dense_shape = [51, 5]  # 假设有 5 个学生
#
# student_sparse_tensor = tf.SparseTensor(student_indices, student_values, student_dense_shape)
#
# # 转换为密集张量
# student_dense_tensor = tf.sparse_tensor_to_dense(student_sparse_tensor)
#
# with tf.Session() as sess:
#     student_dense_result = sess.run(student_dense_tensor)
#     print("学生成绩的密集张量:\n", student_dense_result)
#
#     # 提取最高分的学生
#     max_score_index = tf.argmax(student_dense_tensor, axis=1)
#     max_score = tf.reduce_max(student_dense_tensor, axis=1)
#
#     print("最高分学生编号:", sess.run(max_score_index))
#     print("最高分:", sess.run(max_score))

# # 修改后的代码示例
# # 下面是一个示例代码，展示如何更清晰地输出学生成绩：
# '''
# 稀疏张量转为密集张量是将只存储非零元素的表示转换为包含所有元素的完整表示。
# tf.sparse.to_dense 是 TensorFlow 的一个函数，用于执行这一转换，返回的密集张量中包含所有元素，未指定的元素用默认值填充。
# “稀疏张量转为密集张量” 的中文意思是将只存储非零元素及其位置的稀疏表示转换为一个包含所有元素（包括零元素）的完整表示。
#
# ### 详细解释
#
# - **稀疏张量**：只存储非零的元素和它们的位置，适合大部分元素为零的情况，节省内存。
# - **密集张量**：存储所有元素，包括零元素，适合小型或元素较多的情况。
#
# ### 示例
#
# 假设有一个稀疏张量，它表示为：
#
# ```
# [[0, 3, 0],
#  [0, 0, 7],
#  [5, 0, 0]]
# ```
#
# 这个稀疏张量只存储了非零的元素和它们的位置。将其转换为密集张量后，就会得到一个完整的表示，包含所有元素。
#
# ### `tf.sparse.to_dense` 方法
#
# `tf.sparse.to_dense` 是 TensorFlow 中的一个函数，用于将稀疏张量转换为密集张量。这个函数会将稀疏张量中的非零元素提取出来，并在密集张量中填充零元素。
#
# ### 总结
#
# “稀疏张量转为密集张量”就是将只包含非零元素的稀疏表示转换为包含所有元素的完整表示，而 `tf.sparse.to_dense` 是实现这一转换的具体方法。
# '''
# # 创建稀疏张量表示学生成绩
# student_indices = [[0, 0], [1, 2], [2, 4]]  # 学生编号
# student_values = [85, 90, 75]  # 学生成绩
# student_dense_shape = [5, 5]  # 假设有 5 个学生
#
# # 构建SparseTensor对象，类似于交集返回的对象
# student_sparse_tensor = tf.SparseTensor(student_indices, student_values, student_dense_shape)
# # 转换为密集张量(稀疏张量打印只显示结构信息，而不显示具体数值。使用 tf.sparse.to_dense 方法可以将稀疏张量转换为密集张量，以查看具体的数值。)
# # student_dense_tensor = tf.sparse.to_dense(student_sparse_tensor)
# student_dense_tensor = tf.sparse_tensor_to_dense(student_sparse_tensor)
#
# with tf.Session() as sess:
#     student_sparse_tensor_result = sess.run(student_sparse_tensor)
#     print("学生成绩的稀疏张量:\n", student_sparse_tensor)
#
#     student_dense_result = sess.run(student_dense_tensor)
#     print("学生成绩的密集张量:\n", student_dense_result)
#
#     # 提取最高分的学生
#     max_score_index = tf.argmax(student_dense_tensor, axis=1)
#     max_score = tf.reduce_max(student_dense_tensor, axis=1)
#
#     print("最高分学生编号:", sess.run(max_score_index))
#     print("最高分:", sess.run(max_score))
#
#     # 输出非零成绩
#     non_zero_indices = sess.run(student_sparse_tensor.indices)
#     non_zero_values = sess.run(student_sparse_tensor.values)
#
#     print("非零成绩的学生编号及成绩:")
#     print(non_zero_indices)
#     print(non_zero_values)
#     # for idx, val in zip(non_zero_indices, non_zero_values):
#     #     print(f"学生 {idx[0]} 的成绩: {val}")


# # 示例集合
# keep = tf.constant([1, 2, 3, 4])
# conf_keep = tf.constant([3, 4, 5, 6])
#
# # 计算交集
# intersection = tf.sets.set_intersection(tf.expand_dims(keep, 0), tf.expand_dims(conf_keep, 0))
#
# with tf.Session() as sess:
#     result = sess.run(intersection)
#     print("交集结果:", result)



# '''以下是一个简单的 TensorFlow 示例，展示如何使用 NMS 过滤候选框，并返回最终保留的框和分数：'''
# # 示例候选框坐标 (x1, y1, x2, y2)
# pre_nms_rois = tf.constant([[10, 10, 20, 20],
#                              [12, 12, 22, 22],
#                              [30, 30, 40, 40],
#                              [35, 35, 45, 45]], dtype=tf.float32)
#
# # 示例候选框得分
# pre_nms_scores = tf.constant([0.9, 0.75, 0.8, 0.6], dtype=tf.float32)
#
# # 类别 ID
# class_id = 1  # 假设我们处理的是类别 1
#
# # 假设我们已经得到了与 class_id 相关的索引
# # 这里直接使用所有索引作为示例
# ixs = tf.range(tf.shape(pre_nms_rois)[0])  # 所有框的索引
#
# # 对该类别框执行非极大抑制
# class_keep = tf.image.non_max_suppression(
#     tf.gather(pre_nms_rois, ixs),  # 该类别框的坐标
#     tf.gather(pre_nms_scores, ixs),  # 该类别框的分数
#     max_output_size=2,  # 保留的最大框数量
#     iou_threshold=0.5)  # IoU阈值
#
# # 获取保留的框和分数
# kept_boxes = tf.gather(pre_nms_rois, class_keep)
# kept_scores = tf.gather(pre_nms_scores, class_keep)
#
# # 启动会话以执行图
# with tf.Session() as sess:
#     ixs_result, class_keep_result, kept_boxes_result, kept_scores_result = sess.run([ixs, class_keep, kept_boxes, kept_scores])
#     print("所有索引:\n", ixs_result)
#     print("NMS前的结果:\n", class_keep)
#     print("NMS后的结果:\n", class_keep_result)
#     print("保留的框坐标:\n", kept_boxes_result)
#     print("保留的框得分:\n", kept_scores_result)
# '''
# 代码解释
# 定义候选框和得分：创建包含框坐标和得分的常量张量。
# 索引处理：使用 tf.range 生成所有框的索引。
# 执行 NMS：调用 tf.image.non_max_suppression 进行非极大值抑制。
# 获取结果：通过 tf.gather 提取保留的框和分数。
# 启动会话：在 TensorFlow 1.x 中，需要创建一个会话来执行计算图，并使用 sess.run 获取结果。
# '''

# '''
# 下面是一个简单的代码示例，演示如何使用 tf.pad 函数将张量填充到指定的长度，并用 -1 填充不足的部分。
# 代码解释
# 定义张量：创建一个 class_keep 张量，表示当前保留的框的索引。
# 设定最大实例数量：定义 DETECTION_MAX_INSTANCES，表示希望填充到
# '''
# # 假设我们有一个 class_keep 张量，表示保留的框的索引
# class_keep = tf.constant([0, 2, 4])  # 当前保留的索引
# DETECTION_MAX_INSTANCES = 5  # 设定的最大实例数量
#
# # 计算缺少的个数
# gap = DETECTION_MAX_INSTANCES - tf.shape(class_keep)[0]  # 计算 gap
#
# # 使用 tf.pad 函数进行填充
# # 在最后填充 -1，将长度补足到 DETECTION_MAX_INSTANCES
# class_keep_padded = tf.pad(class_keep, [[0, gap]], mode='CONSTANT', constant_values=-1)
#
# # 启动会话以执行计算
# with tf.Session() as sess:
#     result = sess.run(class_keep_padded)
#     print("填充后的索引:\n", result)


'''
[..., tf.newaxis]写一个代码案例让我快速了解掌握
[..., tf.newaxis] 可以用来在指定位置增加一个新维度。下面是几个代码示例，让你快速掌握它的使用方式。
'''

# 示例 1：在向量末尾增加一个新维度
# 假设我们有一个一维张量
vector = tf.constant([1, 2, 3, 4])  # shape: (4,)

# 使用 tf.newaxis 在末尾增加一个维度
expanded_vector = vector[..., tf.newaxis]  # shape: (4, 1)

with tf.Session() as sess:
    print("Original shape:", vector.shape)
    print("Expanded shape:", expanded_vector.shape)
    print("Expanded vector:\n", sess.run(expanded_vector))

# 示例 2：在二维张量的中间增加一个新维度
# 假设我们有一个二维张量
matrix = tf.constant([[1, 2, 3], [4, 5, 6]])  # shape: (2, 3)

# 在中间增加一个维度，使用 [..., tf.newaxis]
expanded_matrix = matrix[..., tf.newaxis]  # shape: (2, 3, 1)

with tf.Session() as sess:
    print("Original shape:", matrix.shape)
    print("Expanded shape:", expanded_matrix.shape)
    print("Expanded matrix:\n", sess.run(expanded_matrix))

# 示例 3：在二维张量的最前面增加一个新维度
# 使用 tf.newaxis 在最前面增加维度
expanded_matrix_front = matrix[tf.newaxis, ...]  # shape: (1, 2, 3)

with tf.Session() as sess:
    print("Expanded shape (front):", expanded_matrix_front.shape)
    print("Expanded matrix (front):\n", sess.run(expanded_matrix_front))


# # 假设outputs是一个包含几个列表的列表
# outputs = [
#     [1, 2, 3],
#     [4, 5, 6],
#     [7, 8, 9]
# ]
#
# # 使用zip和解包
# # result = zip(*outputs)
# result = zip(outputs)
# print(result)  # 输出: [(1, 4, 7), (2, 5, 8), (3, 6, 9)]
#
# # 使用zip和解包
# result = list(zip(*outputs))
#
# # 结果是：
# # [(1, 4, 7), (2, 5, 8), (3, 6, 9)]
# print(result)  # 输出: [(1, 4, 7), (2, 5, 8), (3, 6, 9)]
# # 使用 zip(*outputs) 会将列表中的每个子列表的对应元素组合成元组。这就是 zip 函数的功能：它将多个可迭代对象的对应元素打包在一起。