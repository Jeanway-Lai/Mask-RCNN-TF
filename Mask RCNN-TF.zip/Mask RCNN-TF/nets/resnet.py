from keras.layers import ZeroPadding2D, Conv2D, MaxPooling2D, BatchNormalization, Activation, Add

'''
导入Keras中的基本层:
- ZeroPadding2D: 用于在输入的周围添加零填充
- Conv2D: 卷积操作
- MaxPooling2D: 最大池化
- BatchNormalization: 批量归一化
- Activation: 激活函数
- Add: 用于将两个张量相加

全局思维：
1. **identity_block**: 是ResNet中的基本构建块之一，主要用于保持输入和输出维度一致。它通过跳跃连接实现了恒等连接，避免了梯度消失问题。内部包含3个卷积层，输入输出相加后通过激活函数。
2. **conv_block**: 和identity_block类似，但是用于改变输入特征图的尺寸。通过strides进行下采样，使得网络可以逐步缩小特征图的大小。
3. **get_resnet**: 是ResNet网络的主干，输入图像后，逐步通过卷积层、池化层和多个stage来提取特征。根据需求可以选择是否使用stage5。最终返回多个不同stage的特征图，这些特征图可以用于后续的RPN、分类器和mask分割网络。
'''


# ------------------------------------#
#   ResNet中的Identity Block
#   没有改变输入尺寸的残差块
# ------------------------------------#
def identity_block(input_tensor, kernel_size, filters, stage, block,
                   use_bias=True, train_bn=True):
    '''
    identity_block函数用于构建ResNet的identity block（恒等块），这种结构不会改变输入的尺寸。
    input_tensor: 输入的张量
    kernel_size: 卷积核大小
    filters: 一个包含三个卷积层过滤器数量的列表
    stage: 阶段标识，用于命名
    block: 块标识，用于命名
    use_bias: 是否使用偏置
    train_bn: 是否在训练时更新BatchNormalization层的参数
    '''

    # 将filters解包为三个值，表示每个卷积层的过滤器数量
    nb_filter1, nb_filter2, nb_filter3 = filters

    # 定义卷积和BatchNormalization层的名称前缀
    conv_name_base = 'res' + str(stage) + block + '_branch'
    bn_name_base = 'bn' + str(stage) + block + '_branch'

    # 第一层卷积，1x1卷积，用来降低维度
    x = Conv2D(nb_filter1, (1, 1), name=conv_name_base + '2a', use_bias=use_bias)(input_tensor)
    # 批归一化
    x = BatchNormalization(name=bn_name_base + '2a')(x, training=train_bn)
    # ReLU激活
    x = Activation('relu')(x)

    # 第二层卷积，kernel_size大小的卷积，保持维度
    x = Conv2D(nb_filter2, (kernel_size, kernel_size), padding='same', name=conv_name_base + '2b', use_bias=use_bias)(x)
    # 批归一化
    x = BatchNormalization(name=bn_name_base + '2b')(x, training=train_bn)
    # ReLU激活
    x = Activation('relu')(x)

    # 第三层卷积，1x1卷积，用来恢复维度
    x = Conv2D(nb_filter3, (1, 1), name=conv_name_base + '2c', use_bias=use_bias)(x)
    # 批归一化
    x = BatchNormalization(name=bn_name_base + '2c')(x, training=train_bn)

    # 将输入张量与卷积输出相加，实现恒等连接
    x = Add()([x, input_tensor])
    # ReLU激活
    x = Activation('relu', name='res' + str(stage) + block + '_out')(x)

    # 返回经过处理的输出张量
    return x


# ------------------------------------#
#   ResNet中的Conv Block
#   改变输入尺寸的残差块
# ------------------------------------#
def conv_block(input_tensor, kernel_size, filters, stage, block,
               strides=(2, 2), use_bias=True, train_bn=True):
    '''''''''
    Conv Block 是 ResNet 中的残差结构之一，用于改变特征图的尺寸或通道数。
    它通过主分支的卷积操作和 shortcut 分支的 1×1 卷积，使两者输出 shape 一致，再通过 Add() 相加。
    conv_block函数用于构建ResNet的conv block（卷积块），这种结构会改变输入的尺寸。
    input_tensor: 输入的张量
    kernel_size: 卷积核大小
    filters: 一个包含三个卷积层过滤器数量的列表
    stage: 阶段标识，用于命名
    block: 块标识，用于命名
    strides: 卷积步幅，默认是(2, 2)，用于缩小特征图尺寸
    use_bias: 是否使用偏置
    train_bn: 是否在训练时更新BatchNormalization层的参数
    '''

    # 将filters解包为三个值，表示每个卷积层的过滤器数量
    nb_filter1, nb_filter2, nb_filter3 = filters

    # 定义卷积和BatchNormalization层的名称前缀
    conv_name_base = 'res' + str(stage) + block + '_branch'
    bn_name_base = 'bn' + str(stage) + block + '_branch'

    # 第一层卷积，1x1卷积，用来降低维度，并且使用strides来缩小特征图尺寸
    x = Conv2D(nb_filter1, (1, 1), strides=strides, name=conv_name_base + '2a', use_bias=use_bias)(input_tensor)
    # 批归一化
    x = BatchNormalization(name=bn_name_base + '2a')(x, training=train_bn)
    # ReLU激活
    x = Activation('relu')(x)

    # 第二层卷积，kernel_size大小的卷积，保持维度
    x = Conv2D(nb_filter2, (kernel_size, kernel_size), padding='same', name=conv_name_base + '2b', use_bias=use_bias)(x)
    # 批归一化
    x = BatchNormalization(name=bn_name_base + '2b')(x, training=train_bn)
    # ReLU激活
    x = Activation('relu')(x)

    # 第三层卷积，1x1卷积，用来恢复维度
    x = Conv2D(nb_filter3, (1, 1), name=conv_name_base + '2c', use_bias=use_bias)(x)
    # 批归一化
    x = BatchNormalization(name=bn_name_base + '2c')(x, training=train_bn)

    # 创建shortcut路径，也就是恒等连接，需要通过1x1卷积调整尺寸
    shortcut = Conv2D(nb_filter3, (1, 1), strides=strides, name=conv_name_base + '1', use_bias=use_bias)(input_tensor)
    shortcut = BatchNormalization(name=bn_name_base + '1')(shortcut, training=train_bn)

    # 将卷积结果和shortcut相加（因为这里他是Add所以shortcut要做一次卷积和最后通道数一样，concat就不需要可以直接用input作为shortcut）
    x = Add()([x, shortcut])
    # ReLU激活
    x = Activation('relu', name='res' + str(stage) + block + '_out')(x)

    # 返回经过处理的输出张量
    return x


# ------------------------------------#
#   构建ResNet模型
#   根据需求选择是否使用stage5
# ------------------------------------#
def get_resnet(input_image, stage5=False, train_bn=True):
    '''''''''
    Introduce:
        构建ResNet网络并返回多个不同stage的特征图
        传入输入图像、train_bn(bool对象)，返回特征图C1、C2、C3、C4、C5，表示不同大小尺度的特征，
    Parameter:
        input_image array: 输入的图像张量
        stage5 bool: 是否使用stage5，默认为False
        train_bn bool: 是否在训练时更新BatchNormalization层的参数
    Return:
        多个尺度的特征图 [C1, C2, C3, C4, C5]
    '''
    # -----------------------------------------------------------------------
    # Stage 1: 输入图像的零填充和卷积操作
    # -----------------------------------------------------------------------
    # Zeropad
    x = ZeroPadding2D((3, 3))(input_image)

    # Conv Block strid=2 shape=(512,512,64)
    x = Conv2D(64, (7, 7), strides=(2, 2), name='conv1', use_bias=True)(x)
    x = BatchNormalization(name='bn_conv1')(x, training=train_bn)
    x = Activation('relu')(x)

    # 使用MaxPooling2D缩小特征图尺寸，Height/4, Width/4, 64  shape=(256,256,64)
    C1 = x = MaxPooling2D((3, 3), strides=(2, 2), padding="same")(x)
    # C1的大小: Height/4, Width/4, 256

    # -----------------------------------------------------------------------
    # Stage 2: ResNet的第二个stage
    # -----------------------------------------------------------------------
    # Conv Block strid=1 shape=(256,256,256)
    x = conv_block(x, 3, [64, 64, 256], stage=2, block='a', strides=(1, 1), train_bn=train_bn)

    # 2个 Identity Block  shape=(256,256,256)
    x = identity_block(x, 3, [64, 64, 256], stage=2, block='b', train_bn=train_bn)
    C2 = x = identity_block(x, 3, [64, 64, 256], stage=2, block='c', train_bn=train_bn)
    # C2的大小: Height/4, Width/4, 256

    # -----------------------------------------------------------------------
    # Stage 3: ResNet的第三个stage
    # -----------------------------------------------------------------------
    # Conv Block strid=2 shape=(128,128,512)
    x = conv_block(x, 3, [128, 128, 512], stage=3, block='a', train_bn=train_bn)

    # 3个 Identity Block  shape=(128,128,256)
    x = identity_block(x, 3, [128, 128, 512], stage=3, block='b', train_bn=train_bn)
    x = identity_block(x, 3, [128, 128, 512], stage=3, block='c', train_bn=train_bn)
    C3 = x = identity_block(x, 3, [128, 128, 512], stage=3, block='d', train_bn=train_bn)
    # C3的大小: Height/8, Width/8, 512

    # -----------------------------------------------------------------------
    # Stage 4: ResNet的第四个stage
    # -----------------------------------------------------------------------
    # Conv Block strid=2 shape=(64,64,1024)
    x = conv_block(x, 3, [256, 256, 1024], stage=4, block='a', train_bn=train_bn)

    # 22个 Identity Block  shape=(64,64,1024)
    block_count = 22
    for i in range(block_count):
        x = identity_block(x, 3, [256, 256, 1024], stage=4, block=chr(98 + i), train_bn=train_bn)
    C4 = x
    # C4的大小: Height/16, Width/16, 1024

    # -----------------------------------------------------------------------
    # Stage 5: 根据stage5参数决定是否构建
    # -----------------------------------------------------------------------
    if stage5:
        # Conv Block strid=2 shape=(32,32,2048)
        x = conv_block(x, 3, [512, 512, 2048], stage=5, block='a', train_bn=train_bn)

        # 2个 Identity Block  shape=(32,32,2048)
        x = identity_block(x, 3, [512, 512, 2048], stage=5, block='b', train_bn=train_bn)
        C5 = x = identity_block(x, 3, [512, 512, 2048], stage=5, block='c', train_bn=train_bn)
        # C5的大小: Height/32, Width/32, 2048
    else:
        C5 = None

    # 返回多个尺度的特征图
    return [C1, C2, C3, C4, C5]
