from keras.layers import Input  # 导入Input类，用于构建模型输入层
from mask_rcnn import MASK_RCNN  # 导入自定义的MASK_RCNN类
from PIL import Image  # 导入PIL库的Image模块，用于图像处理

# tf.get_logger().setLevel('ERROR')    # 使用日志级别过滤来隐藏WARNING这些警告信息

"""""""""
主要用于加载图片，调用 Mask R-CNN 模型进行预测，并显示结果。
"""

mask_rcnn = MASK_RCNN()  # 实例化一个MASK_RCNN对象

# while True:   # 无限循环
# img = input('img/street.jpg')  # 这里需要输入

# 要检测的图片
img = 'img/street.jpg'  # 指定要检测的图片路径
# img = 'img/花花.jpg'  # 指定要检测的图片路径

try:
    image = Image.open(img)  # 尝试打开图片文件

except:
    print('Open Error! Try again!')  # 如果打开失败，打印错误信息
    # continue
    raise '没有文件'  # 抛出异常，提示没有文件

else:
    # 检测图片
    mask_rcnn.detect_image(image)  # 使用Mask RCNN模型检测图片中的目标

mask_rcnn.close_session()  # 关闭模型的会话